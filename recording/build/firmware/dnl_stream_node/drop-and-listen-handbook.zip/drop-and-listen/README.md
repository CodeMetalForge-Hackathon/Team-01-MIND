# Drop-and-Listen

Cheap listening nodes that locate a person who knocks, calls or coughs, by timing when the sound
reaches each node. Sounds are trusted only when several nodes agree, then classified and sent to
ATAK. Code Metal Forge Hackathon 2026, Operation Lost and Found.

| Folder | Contents | Status |
| --- | --- | --- |
| `firmware/stream` | Streaming firmware for all three nodes, plus per-node debug sketches | Working on hardware |
| `python` | `record_plot.py`: record, detect, triangulate, plot | Working on real recordings |
| `laptop` | Validation levels, classification rules, ATAK output, dashboard, simulator | Tested in simulation |
| `firmware/mesh` | Wireless nodes, gateway, LoRa receiver | Not yet tested on hardware |
| `docs/HANDBOOK.md` | Everything: setup, wiring, results, bugs fixed, task list | |

Quick start (Windows PowerShell, three nodes on COM11-13):

```powershell
cd python
pip install -r requirements.txt
python record_plot.py both --ports COM11 COM12 COM13 --seconds 30 --out data/run.npz --pos 1=0,0 2=2.5,0 3=1.25,2
```

## Team

| Name | Role |
| --- | --- |
| Siddhi More | TODO |
| TODO | TODO |

## What existed before the event
The idea and planning documents. All code was written during the build window.

## Credits
Arduino-ESP32 / ESP-IDF, RadioLib, NumPy, Matplotlib, PyYAML, pyserial.

## License
MIT
