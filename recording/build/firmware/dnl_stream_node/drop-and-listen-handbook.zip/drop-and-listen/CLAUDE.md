# CLAUDE.md

Read `docs/HANDBOOK.md` first. It holds the full history, the working setup, the results, the bugs
already fixed and the task list (section 14).

## What works today (proven on hardware)
- `firmware/stream/dnl_stream_node`: the same sketch on all three nodes (Feather ESP32-S2 = node 1 and
  time master, XIAO ESP32-C5 = node 2, XIAO ESP32-S3 Plus = node 3). Raw Grove samples over USB with
  shared-clock timestamps (ESP-NOW beacons from node 1).
- `python/record_plot.py`: records all three, detects knocks, matches across nodes (with guided search),
  triangulates, plots per node and an overview.

## Built but not proven on hardware
- `firmware/mesh`: wireless nodes, gateway, LoRa receiver.
- `laptop/dnl`: validation levels, rule-based classification, ATAK CoT, dashboard, simulator
  (12 unit tests pass; `python -m dnl.main --sim` runs end to end).

## Rules
- Deadline Sunday 12:00, tag `submission`. Small commits. A working demo beats more features.
- Never commit `data/` or any `.npz`: recordings can contain people's voices.
- Everything on the laptop must run on a saved recording or a simulator, with no hardware attached.
- Don't claim hardware works. Tell the user what to upload and what they should see.
- Keep thresholds, node positions and ATAK settings in config files, not in code.
- Don't reintroduce the bugs in HANDBOOK section 9: ports must open with DTR on (S2 TinyUSB);
  C5/S3 USB writes must be whole packets with a large TX buffer; sample timing must use the windowed
  fit that resets after stalls/overflows; node IDs must be unique.
- The three `protocol.h` copies in `firmware/mesh` must stay identical.

## Task order (details and acceptance checks in HANDBOOK section 14)
1. T1 live mode for the streaming setup
2. T2 sound classification on real recordings
3. T3 accuracy test tooling against measured positions
4. T4 ATAK output
5. T5 LoRa alert link (USB → LILYGO #1 → LoRa → LILYGO #2 → USB)
6. T6 validation levels and dashboard in live mode
7. T7 stretch: wireless nodes
