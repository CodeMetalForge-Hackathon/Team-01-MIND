# Drop-and-Listen Handbook

Everything built, measured and learned so far, written so a teammate or Claude Code can pick up
the work without the chat history. Code Metal Forge Hackathon 2026, Operation Lost and Found,
BASE-X Boston, Nov 7–8. Submission deadline: **Sunday 12:00**, tagged `submission`.

Contents

1. The project in one page
2. Rules that constrain the work
3. Where things stand right now
4. Hardware: what we have, what each board does
5. Wiring
6. Firmware (working path): `firmware/stream`
7. Python recording, detection and triangulation: `python/record_plot.py`
8. Results so far
9. Bugs we hit and how they were fixed (don't reintroduce these)
10. Known limits of the current system
11. Sound classification: what exists and what to build
12. The laptop package from the earlier design: `laptop/dnl`
13. The wireless design (not yet proven on hardware): `firmware/mesh`
14. Tasks for Claude Code, in order, with acceptance checks
15. Demo plan and how it maps to judging
16. Command cheat sheet
17. Troubleshooting
18. Glossary

---

## 1. The project in one page

**Problem.** After a disaster or in dense terrain, a trapped or lost person may knock, shout or
cough, but rescuers can't listen everywhere at once, and listening devices today need a person
standing next to them.

**Idea.** Cheap listening nodes placed around an area keep listening on their own. A sound reaches
each node at a slightly different time. Those time differences (TDOA, time difference of arrival)
pin down where the sound came from. Sounds are only trusted when several nodes agree, then they're
classified (knock, voice, cough, noise) and the location goes to the map responders already use
(ATAK, the Android Team Awareness Kit).

**Why it fits the challenge.** Objective 2 (find people: heat, motion, sound) and deployability
(cheap, no infrastructure, feeds ATAK). The distinctive points are persistence (nodes keep
searching when nobody is there) and multi-node validation (cuts false alarms).

**Judging criteria (equal weight):** real-world relevance, a working live demo, deployability,
ideation.

## 2. Rules that constrain the work

- Only code written during the event counts. Document what existed before (ideas and planning docs).
- Never commit secrets, and **never commit audio recordings of real people**. Our `.npz`
  recordings can contain background chatter, so `data/` is git-ignored. Keep it that way.
- Model weights, if any, go through Git LFS, not plain git.
- License: MIT (in `LICENSE`).
- Submission: last commit on the default branch at or before 12:00 Sunday, then
  `git tag submission && git push origin submission`.

## 3. Where things stand right now

**Working, proven on hardware (Sunday ~01:30):**

- Three nodes, each an ESP32 board with a Grove Sound Sensor, streaming raw samples to the laptop
  over USB through a hub.
- All three on one shared clock. Node 1 broadcasts its clock over ESP-NOW; nodes 2 and 3 sync to
  it. Arrival times of the same knock agree across nodes to within the physically possible window.
- `python/record_plot.py` records all three at once, detects knocks, matches them across nodes,
  triangulates, and plots each node (ADC vs ms, ADC vs distance) plus an overview with a map.
- On the recording `quiet_spot6.npz`, six knocks were located with all three nodes.

**Exists but not yet proven on hardware:**

- The wireless design: detection on each node, ESP-NOW to a gateway, LoRa to a command post
  (`firmware/mesh`).
- The laptop package `laptop/dnl` (multi-node validation, rule-based classification, ATAK CoT
  output, live dashboard, simulator). Unit-tested and run end to end on simulated data, but built
  for the wireless design's JSON messages, not for the raw streams we use now.

**Not started:** live mode for the streaming setup, classification on real recordings, the ATAK
marker from real data, the LoRa link, an accuracy test against measured positions.

## 4. Hardware: what we have, what each board does

| Role | Board | USB ID | Port (on Siddhi's laptop) | Notes |
| --- | --- | --- | --- | --- |
| Node 1, time master | Adafruit Feather ESP32-S2 (ESP32-S2-MINI-1 module) | `239A:80EB` | COM11 | Native USB via TinyUSB. Has a LiPo socket and a STEMMA QT (I2C) socket |
| Node 2 | Seeed XIAO ESP32-C5 | `303A:1001` | COM12 | USB-Serial-JTAG. Its ADC seems to run near 11.17 kHz when 10 kHz is requested (firmware now reports the measured rate) |
| Node 3 | Seeed XIAO ESP32-S3 Plus | `303A:1001` | COM13 | USB-Serial-JTAG |
| Sensors | 3 × Grove Sound Sensor | | | Output is one-sided and loudness-shaped, not a full audio wave. Powered at 3.3 V |
| LoRa pair | 2 × LILYGO LoRa32 915 MHz (ESP32 + SX1276) | | | Antennas must be fitted before powering. Pins assume T3 V1.6.x: check the board |
| Extras (later) | Grove IMU, Grove temp/humidity, Grove vibration, HTI thermal imager | | | Not wired yet |
| Spare | 2 × ICS-43434 I2S MEMS mics | | | See the MEMS lesson in section 9 |

Ports can change after a board enters upload mode. Check with `python -m serial.tools.list_ports -v`.
The two Espressif boards share a USB ID; tell them apart by the `SER=` value or by unplugging one.

## 5. Wiring

Each node has one Grove Sound Sensor on its own breadboard. Grove colours: yellow = signal,
white = not used, red = 3.3 V, black = GND.

| Node | Board | Yellow (signal) | Red | Black |
| --- | --- | --- | --- | --- |
| 1 | Feather ESP32-S2 | pin **9** (top header row) | 3V | GND |
| 2 | XIAO ESP32-C5 | **D0** (GPIO1) | 3V3 | GND |
| 3 | XIAO ESP32-S3 Plus | **D0** (GPIO1) | 3V3 | GND |

Pin rules learned the hard way:

- Only ADC1 pins work alongside Wi-Fi/ESP-NOW. On the Feather S2 and S3 Feathers, A0–A4 are on ADC2:
  don't use them. Pin 9 (and 5, 6, 10) are ADC1.
- On the XIAO ESP32-C5, D0 is the only analog header pin. GPIO4/GPIO5 are JTAG pads on the back and
  GPIO6 measures the battery: don't use them.
- XIAO D0 is the first pin on the left side next to the USB-C connector; 3V3 and GND are on the
  right side near the USB end. Use 3V3, never the 5V pin.
- The Feather S2 switches power to its STEMMA QT socket. To use I2C sensors there, drive
  `NEOPIXEL_I2C_POWER` high before `Wire.begin()`.

Layout used so far: a triangle, nodes nominally at (0, 0), (2.5, 0) and (1.25, 2) metres. **These
positions were never measured.** Measure them before trusting any position.

Power: all nodes on laptop USB through a hub (a powered hub is better). USB carries both power and
data in the streaming design.

## 6. Firmware (working path): `firmware/stream`

Arduino IDE, board package **esp32 by Espressif 3.3.5 or newer** (needed for the C5),
**USB CDC On Boot: Enabled** for every board. Boards in Tools → Board: *Adafruit Feather ESP32-S2*,
*XIAO_ESP32C5*, *XIAO_ESP32S3_PLUS* (or *XIAO_ESP32S3*; D0 is the same pin).

### 6.1 Debug sketches (text only)

`node1_s2_debug`, `node2_c5_debug`, `node3_s3_debug`. Each reads its Grove sensor with
`analogRead` at 4 kHz and prints, every 2 s, raw min/max/mean/spread, the noise floor and a verdict
("ok: signal is alive", "flat", "reads ~0 V", "stuck at maximum"), plus one line per detected sound
with its features and a guess (knock, voice, cough, impact, steady noise). Serial Monitor 115200.
Set `PLOTTER = true` for the Serial Plotter.

### 6.2 `dnl_stream_node` (the same sketch on all three boards)

What it does:

1. **Node ID** is automatic by chip: S2 = 1, C5 = 2, S3 = 3. `FORCE_NODE_ID` overrides it
   (set it, upload, set it back to 0). A `MAC_TABLE` exists for boards of the same chip.
2. **Sampling.** ESP-IDF continuous ADC driver at `FS_HZ` = 10 kHz on one ADC1 channel. The output
   format differs by chip: TYPE1 (`p->type1.channel/data`) on ESP32/S2, TYPE2 on C5/S3. Both are
   handled with macros.
3. **Shared clock.** Node 1 broadcasts `{0xB5, seq, master_us}` over ESP-NOW (broadcast address,
   2.4 GHz channel 1, every 0.5 s). Nodes 2 and 3 note their own clock when each beacon arrives and
   fit a straight line (offset and drift) through the last 8 beacons. Every node receives the same
   beacon at practically the same instant, so this aligns them to tens of microseconds. The C5 is
   forced to 2.4 GHz (`esp_wifi_set_band_mode`).
4. **Sample timing.** Each ADC read gives a batch of samples and the time it arrived. A line is
   fitted through the last ~64 batches (sample index → local time), using only reads that actually
   waited for data (catch-up reads arrive too early). The fit **restarts after an ADC overflow or a
   stall over 100 ms**. Sanity limits reject fits outside 0.5–2× the nominal rate.
5. **Packets over USB**, 250 samples each (25 ms at 10 kHz):

   | Field | Type | Meaning |
   | --- | --- | --- |
   | magic | uint16 | `0x5AA6` |
   | node | uint8 | 1–3 |
   | synced | uint8 | 1 if timestamps are on the shared clock |
   | seq | uint16 | packet counter (gaps = dropped packets) |
   | fs_hz | uint32 | measured sample rate |
   | first_index | uint32 | index of the first sample |
   | first_t_us | int64 | shared-clock time of the first sample, µs |
   | n | uint16 | samples in this packet (250) |
   | overflows | uint8 | ADC overflows since the last packet |
   | reserved | uint8 | 0 |
   | samples | uint16 × n | raw 12-bit ADC values |
   | checksum | uint16 | byte sum of header + samples, mod 65536 |

   Header is 26 bytes, little-endian, packed (`struct.Struct("<HBBHIIqHBB")` in Python).
6. **USB on C5/S3** (USB-Serial-JTAG, `ARDUINO_USB_MODE` = 1): TX buffer set to 4096 bytes before
   `begin()`, TX timeout 0, and a packet is only written if `availableForWrite()` can take all of
   it; otherwise it's skipped whole and shows up as a dropped packet. This keeps the board from
   stalling when no laptop is reading and never sends a half packet.
7. One text line at boot (`DNL node N ... MAC ... pin ...`); everything after is binary.

Uploading: one board at a time, correct board + port each time. If the port vanishes mid-upload,
hold BOOT, tap RESET, release BOOT, select the new port, upload, then tap RESET so the sketch runs.
Close the Arduino IDE afterwards, or it holds the COM ports.

## 7. Python recording, detection and triangulation: `python/record_plot.py`

Requirements: `pyserial`, `numpy`, `matplotlib`. Run from the `python` folder.

```powershell
python record_plot.py both --ports COM11 COM12 COM13 --seconds 30 --out data/run.npz --pos 1=0,0 2=2.5,0 3=1.25,2
python record_plot.py record --ports COM11 COM12 COM13 --seconds 30 --out data/run.npz
python record_plot.py plot data/run.npz --pos 1=0,0 2=2.5,0 3=1.25,2
```

Options: `--settle 3` (seconds to let clocks sync before recording), `--temp 20` (air °C),
`--detector level|sharp`, `--k 5` (level detector), `--ratio 6` (sharp detector),
`--no-guided`, `--sound N` (which sound to plot), `--save-only`.

### 7.1 Recording

- One thread per port. Ports open normally (DTR on: the S2's TinyUSB only sends while DTR is set).
- Packets are found by magic number and checksum, so stray text is skipped.
- First `--settle` seconds are discarded; packets with `synced = 0` are discarded and counted.
- Per node it stores sample times (`n{N}_t_us`), raw values (`n{N}_adc`), header rate (`n{N}_fs`)
  and packet size (`n{N}_pkt`) in an `.npz`, plus `nodes`.
- Diagnostics printed: samples and seconds per node, synced %, dropped packets, overflows,
  backward jumps in timestamps, two ports claiming the same node ID, and for silent ports whether
  they sent no bytes (not running) or bytes without valid packets (wrong sketch).

### 7.2 Analysis

1. **Timing repair** (`fix_timing`): the real sample rate is measured from the spacing of packet
   start times and sample times are rebuilt per packet. Protects against boards that don't sample
   at the rate they claim.
2. **Envelope:** distance from a 1 s moving average of the raw signal, averaged over 0.7 ms.
3. **Detection, default `level`:** threshold = max(k × median envelope, 15 counts), k = 5. Onset =
   walk back from the crossing to 30 % of the threshold, then interpolate between samples. 0.3 s
   refractory period. **Option `sharp`:** last 2 ms vs the 50 ms before it; tested on real data and
   found fewer knocks than `level` because the Grove signal is spiky, so it isn't the default.
4. **Matching across nodes:** detections can be the same sound if their time gap is no more than
   (distance between the two nodes / speed of sound) + 5 ms. Per node the clearest candidate (highest
   SNR) is taken.
5. **Guided search:** if two nodes heard a sound, it happened, so the third node's envelope is
   searched around that time using its local background (median of the 100 ms before the window).
   Accepted if its peak is at least 3× that background and the onset is physically consistent.
   Marked with `*` in the table. On real data this doubled the triangulated knocks.
6. **Triangulation** (3+ nodes): unknowns x, y and emission time t0. For node i at p_i heard at t_i:
   |(x, y) − p_i| = c (t_i − t0). Gauss–Newton least squares from five starting points, best fit
   kept. Uncertainty: 95 % radius from (c σ_t)² (JᵀJ)⁻¹ with σ_t = 0.2 ms.
   **With exactly three nodes the system is exactly determined: the fit error is always 0** and
   the distance plots always line up. Accuracy can only be judged against measured positions or with
   a fourth node.
7. Speed of sound: c = 331.4 + 0.6 T + 0.0124 RH (m/s).

### 7.3 Plots (saved to `data/<run>/plots/`)

Per node: (1) ADC vs time in ms, whole recording, onsets in red; (2) ADC vs time in ms, zoom on the
chosen sound; (3) ADC vs distance travelled by the sound since it was made (m), with the node's
computed distance to the source in green. `overview.png`: all nodes on one time axis (the same knock
should line up vertically) and a map of nodes and triangulated sounds. Windows open stacked; look
for several "Figure" windows.

## 8. Results so far

### 8.1 Timing agreement (`quiet_spot5`, nodes 1 and 2)

| Sound | Node 1 (ms) | Node 2 (ms) | Gap |
| --- | --- | --- | --- |
| 4 | 9787.17 | 9784.95 | 2.2 ms |
| 6 | 11098.61 | 11099.06 | 0.5 ms |
| 10 | 20802.94 | 20799.26 | 3.7 ms |
| 11 | 21503.50 | 21499.41 | 4.1 ms |

All gaps are under the 7.3 ms sound needs to cross 2.5 m, so the shared clock works.

### 8.2 Three nodes (`quiet_spot6`, 30 s, all synced 100 %, 0 dropped, 0 overflows)

| Node | Noise floor (counts) | Threshold at k = 5 | Detections |
| --- | --- | --- | --- |
| 1 (S2) | 188.6 | 942.9 | 10 |
| 2 (C5) | 147.0 | 734.9 | 13 |
| 3 (S3) | 3.2 | 15.9 | 15 |

Triangulated knocks (with guided search; `*` marks found by guided search):

| Sound | t1 (ms) | t2 (ms) | t3 (ms) | Position (m) | 95 % radius |
| --- | --- | --- | --- | --- | --- |
| 2 | 7386.57* | 7392.10 | 7391.83 | (0.29, 0.11) | 0.22 |
| 6 | 8905.63 | 8903.77* | 8903.55 | (1.65, 0.90) | 0.17 |
| 8 | 11724.50 | 11725.84* | 11722.69 | (0.93, 1.18) | 0.18 |
| 13 | 17144.72 | 17141.13 | 17143.77 | (1.93, 0.48) | 0.19 |
| 14 | 18614.44 | 18613.26 | 18611.17 | (1.54, 1.22) | 0.18 |
| 20 | 24838.27 | 24839.12 | 24841.32 | (1.10, −0.16) | 0.24 |

What the data says:

- Node 3's sensor gives much smaller signals (knocks ~100 counts) but almost no background, so its
  knocks stand out ~30× above noise. Nodes 1 and 2 pick up a lot of room sound and their knocks are
  only 3–5× above it. Node 3 is the cleanest node, not the weakest.
- Lowering k to 3.5 made nodes 1 and 2 fire 43 and 48 times on room noise and **no** knock was
  triangulated. Lower thresholds aren't the fix; better detection and quieter spots are.
- Several knocks reached only nodes 1 and 3. Knocking harder, inside the triangle, on something
  that rings (a pan, a hard box) gets more three-node detections.
- Positions are relative to unmeasured node positions. No accuracy claim is possible yet.

## 9. Bugs we hit and how they were fixed (don't reintroduce these)

| Symptom | Cause | Fix |
| --- | --- | --- |
| Flat recording on the S2 | Firmware read GPIO1 while the sensor was on the Feather pin labelled A1 (GPIO17) | Use pin 9 (ADC1). Feather "A" labels are not GPIO numbers |
| Node 2 had twice the expected samples, scrambled timeline, node 3 missing | C5 and S3 both reported node 2; the recorder merged them | IDs automatic by chip; recorder warns and ignores a second port claiming the same ID |
| Node 1 suddenly sent nothing | Recorder opened ports with DTR off; TinyUSB on the S2 only sends while DTR is on | Open ports normally |
| Node 2 timestamps jumped backwards ~600 times, claimed 1 kHz | Before Python opened the port, the C5's USB writes blocked, samples were lost, and the timing fit (averaged since boot) was poisoned | Windowed timing fit that restarts after overflow or stall; non-blocking USB |
| COM12/COM13 sent lots of bytes but no valid packets | TX timeout 0 with the default USB TX buffer smaller than one 528-byte packet: every packet got cut off | 4 KB TX buffer and whole-packet-only writes |
| `redefinition of 'double fitA'` | Timing variables reused clock-sync names | Timing variables renamed `tFitA`, `tRefIdx`, `tRefT` |
| "Access is denied" on a port | Arduino IDE or a leftover Python process holding it | Close the IDE; `Get-Process python | Stop-Process` |
| "Device does not exist" during upload | Native-USB boards re-enumerate under a new COM number in upload mode | BOOT + RESET by hand, pick the new port, RESET after upload |

**The MEMS microphone detour (several hours, abandoned).** Two ICS-43434 I2S mics sharing one bus
(SEL to GND and to 3V) on the ESP32-S2: the right slot worked, the left slot always read 0 in
32-bit stereo, also with `msb_right`/`ws_pol` changes and 16-bit-in-32-bit slots. One board also had
a solder bridge between LRCL and DOUT (neighbouring pins), which made the data line read the WS
clock (`00000001` / `FFFFFFFE` pattern). There was also confusion between SPH0645 and ICS-43434
boards (same pin order, different timing). Lesson: prove a two-mic I2S setup on the target chip in
the first hour, and inspect solder joints first. MEMS stays a "better sensor" roadmap item.

## 10. Known limits of the current system

- The Grove sensor's output is one-sided and loudness-shaped, so classification can use timing and
  shape but not pitch.
- Nodes are tethered by USB. That's fine for the demo; deployment needs the wireless design.
- 10 kHz sampling = 100 µs per sample (~3.4 cm of sound travel); sub-sample onset interpolation helps,
  but onset definition on a noisy one-sided signal is the bigger error source.
- Node 3's sensor differs in gain from the others. Different sensors can respond with slightly
  different delays, which biases positions. Identical sensors are better.
- Three nodes give no internal accuracy check (exactly determined).
- Echoes from walls and tables can trigger detections; nodes should sit on soft pads and knocks should
  be on a held object, not the table the nodes sit on.

## 11. Sound classification: what exists and what to build

### 11.1 Features (defined in the node firmware's `detector.h` and the debug sketches)

| Feature | Definition | Why it separates sounds |
| --- | --- | --- |
| `rise_ms` | onset → envelope peak | Knocks rise in a few ms; voices and coughs rise more slowly |
| `dur_ms` | onset → last moment the slow envelope (15 ms) was above 1.8 × the floor, ending after 150 ms of quiet or 2 s | Knocks are short; voices longer; machinery very long |
| `mod_hz` | peaks in the slow envelope (sampled every 10 ms, 25 % hysteresis, peaks above 35 % of max) ÷ duration; 0 unless ≥ 2 peaks and duration > 250 ms | Speech rises and falls with syllables, ~3–8 per second |
| `peak`, `floor`, `snr` | envelope peak, noise floor before the sound, their ratio | Confidence; very loud single impacts |
| `energy` | summed envelope | Relative loudness × duration |

### 11.2 Current rules (`laptop/dnl/classify.py`, thresholds in `laptop/config.yaml`)

| Label | Rule | Person-like? |
| --- | --- | --- |
| steady | dur ≥ 1500 ms and mod < 1.5 Hz | No |
| knock_tap | rise ≤ 6 ms and dur ≤ 150 ms | Yes, more so when repeated |
| impact | rise ≤ 6 ms and dur > 150 ms (slam, drop) | No |
| voice | 150 ≤ dur ≤ 2500 ms and 2.5 ≤ mod ≤ 9 Hz | Yes |
| cough | 80 ≤ dur ≤ 700 ms, rise > 6 ms, mod < 2.5 Hz | Yes |
| other | anything else | No |

These were checked on synthetic signals only. The detector in `detector.h` gave knock (rise 1.6 ms,
dur 73 ms), voice (dur 949 ms, 5.3 Hz) and cough (dur 313 ms, mod 0) correctly on synthetic input.

### 11.3 What to build (task T2)

1. A feature extractor in Python that takes one node's raw samples around a detected onset
   (from the `.npz`) and computes the features above, matching the firmware definitions.
2. Per triangulated sound, classify using the node with the highest SNR; record all nodes' labels.
3. A labelled dataset: record sessions where each sound type is made on purpose (knocks, short
   phrases, coughs, claps, door slams, dropped objects, steady noise), with a small text file of
   what was done when. Only team members' voices, with their consent; recordings stay out of git.
4. Evaluate the rules on that dataset: a confusion matrix and per-class accuracy. Tune thresholds.
   Only then consider a small learned model (e.g. a random forest on the features), split by
   session, not by clip.
5. Plot duration vs syllable rate coloured by true label (good for the pitch).

## 12. The laptop package from the earlier design: `laptop/dnl`

Built for the wireless design's JSON events; useful parts for the streaming setup:

| Module | What it does | Reuse now? |
| --- | --- | --- |
| `classify.py` | Rule classifier on `SoundEvent` features | Yes, feed it features computed from raw streams |
| `validate.py` | Groups detections across nodes; levels unconfirmed / confirmed / likely_person; repetition and vibration votes | Yes, the level logic and repeated-knock rule |
| `locate.py` | 1-node zone, 2-node hyperbola, 3+ node TDOA | Overlaps with `record_plot.py`; keep one implementation |
| `atak.py` | Local metres → lat/lon; CoT XML; UDP multicast to 239.2.3.1:6969 | Yes, for task T4 |
| `dashboard.py` | Live matplotlib map and log | Yes, as a base for live mode |
| `sources.py`, `main.py` | Serial JSON source, simulator, CLI | Pattern only |
| `logger.py` | Raw lines and decisions to `data/runs/<timestamp>/` | Yes |

Tests: `cd laptop && python -m pytest` (12 tests; pass). `python -m dnl.main --sim` runs the whole
pipeline on simulated nodes.

Confidence levels to keep:

| Level | Rule | ATAK |
| --- | --- | --- |
| unconfirmed | one node only, or not synced | no |
| confirmed | 2+ nodes within the travel-time window | no (optional) |
| likely_person | confirmed and (voice or cough, or knocks repeating 0.25–2 s apart within 4 s from about the same place, or a vibration vote) | yes |

## 13. The wireless design (not yet proven on hardware): `firmware/mesh`

- `node/`: detection and feature extraction on the board, synced timestamps, ESP-NOW packets
  (SOUND, STATUS, VIB), optional IMU (MPU6050 family or LSM6DS3) and DHT20 on I2C, optional Grove
  vibration on a digital pin.
- `gateway/`: LILYGO #1. Beacon every second, ESP-NOW in, JSON lines on USB, LoRa out (RadioLib).
- `lora_rx/`: LILYGO #2. LoRa in, the same JSON on USB.
- `espnow_test/`, `grove_test/`: bring-up sketches.
- Protocol in each `protocol.h` (three identical copies). The node `config.h` pin block covers C5
  and S2; add `CONFIG_IDF_TARGET_ESP32S3 → SOUND_PIN 1` before using it on the S3 Plus.

Use this only after the demo path is solid. It's the riskiest remaining work (3–5 h).

## 14. Tasks for Claude Code, in order, with acceptance checks

Ground rules: small commits; never commit `data/`; everything must run on an existing recording or
a simulator without hardware; don't claim hardware works; tell the user what to flash and what they
should see.

**T1. Live mode** (highest value for the demo). Extend `record_plot.py` (or a new `live.py`) to keep
reading all three ports, keep a rolling buffer (~3 s per node), run detection, matching, guided
search and triangulation on new data every ~0.2 s, and update a map with each located knock.
Print one line per sound. Save everything to `data/live/<timestamp>.npz` at exit.
*Done when:* replaying `quiet_spot6.npz` through a fake-serial source shows the same six positions
as the batch analysis, and latency from knock to dot is under 2 s.

**T2. Classification** (section 11.3). *Done when:* each located sound has a label and confidence,
the rules are evaluated on a labelled session with a confusion matrix, and thresholds live in a
config file.

**T3. Accuracy test tooling.** A small YAML with measured node positions and knock spots; a command
that, for each recording, compares triangulated positions with the spot and reports mean error,
spread and a plot. *Done when:* it runs on a recording plus a ground-truth file and prints error in cm.

**T4. ATAK output.** Reuse `laptop/dnl/atak.py`. Send likely_person sounds (or all triangulated ones,
configurable) as CoT; node positions as friendly markers. Map origin from config (`lat0`, `lon0`,
x-axis bearing). *Done when:* `--atak` sends valid CoT to UDP multicast and a test listener receives it.

**T5. LoRa alert link.** Simple bridge firmware: LILYGO #1 reads JSON lines from USB and sends them
over LoRa; LILYGO #2 receives and prints them on USB. Laptop sends each located sound to #1. Shows
the off-grid hop without changing the nodes. *Done when:* a sound sent to #1 is printed by #2.

**T6. Merge with `laptop/dnl` validation levels** and the dashboard, so the live view shows grey /
orange / red by level.

**T7. Stretch: wireless nodes** (section 13).

## 15. Demo plan and how it maps to judging

1. Three nodes on the table in a triangle; laptop map open; ATAK phone visible.
2. Slam something next to one node: shown as single-node or rejected, no marker.
3. Knock three times inside the triangle on a pan: dots appear where you knocked; the repeated
   pattern becomes "likely a person"; marker on ATAK.
4. Say a short phrase: labelled voice.
5. Show the accuracy numbers from the tape-mark test and the overview plot.
6. If the LoRa link works: the alert arrives on the second LILYGO across the room.

| Criterion | What shows it |
| --- | --- |
| Real-world relevance | Locating someone who knocks or calls; feeding ATAK |
| Working demo | Live dots and markers, three times in a row |
| Deployability | Cheap boards, shared clock over ESP-NOW, LoRa hop, battery-capable roadmap |
| Ideation | Multi-node validation to reject false alarms; persistence |

Be honest in the pitch about what isn't done (wireless nodes, three-node accuracy limits) and about
the MEMS detour: diagnosis and adaptation count in your favour.

## 16. Command cheat sheet (Windows PowerShell)

```powershell
python -m serial.tools.list_ports -v                       # which board is on which COM port
Get-Process python -ErrorAction SilentlyContinue | Stop-Process   # free ports held by old runs
cd python
pip install -r requirements.txt
python record_plot.py both --ports COM11 COM12 COM13 --seconds 30 --out data/spotA.npz --pos 1=0,0 2=2.5,0 3=1.25,2
python record_plot.py plot data/spotA.npz --pos 1=0,0 2=2.5,0 3=1.25,2 --sound 6
cd ../laptop
pip install -r requirements.txt
python -m pytest
python -m dnl.main --sim
```

## 17. Troubleshooting

| Message or symptom | Do this |
| --- | --- |
| `could not open port ... FileNotFoundError` | Wrong COM number: list ports again |
| `Access is denied` | Close the Arduino IDE; stop leftover Python processes; replug the board |
| `!! COMx: no bytes at all` | Board not running: press RESET, check the cable, re-upload |
| `!! COMx: received N bytes but no valid packets` | Wrong sketch (e.g. a debug sketch): upload `dnl_stream_node` |
| `!! COMx and COMy both say they are node N` | Set `FORCE_NODE_ID` on one board and re-upload |
| `timestamps jumped backwards` | Old firmware: upload the current `dnl_stream_node` |
| Synced below 100 % | Node 1 (S2) must be running; keep boards within a few metres |
| Dropped packets | Powered hub, shorter cable, or plug that board straight into the laptop |
| Knocks found on only one or two nodes | Knock harder, inside the triangle, on a pan; try a quieter spot |
| Hundreds of detections | Threshold too low; go back to `--k 5` |
| Only one plot window | Windows are stacked; check the taskbar or `data/<run>/plots/` |

## 18. Glossary

| Term | Plain meaning |
| --- | --- |
| TDOA | Time difference of arrival: how much later a sound reached one node than another |
| Triangulation / multilateration | Working out the position from those time differences |
| Onset | The moment a sound starts at a node |
| Envelope | A smoothed "how loud right now" curve |
| Noise floor | Typical loudness when nothing is happening |
| SNR | How far a sound stands out above the noise floor |
| ESP-NOW | Espressif's router-free radio link between ESP32 boards |
| Shared clock | All nodes timestamping on node 1's clock, via ESP-NOW beacons |
| ADC1 / ADC2 | The ESP32's two analog converters; ADC2 conflicts with Wi-Fi |
| CoT | Cursor on Target: the XML message format ATAK uses for map markers |
| ATAK | Android Team Awareness Kit: the map app many responders use |
| LoRa | Long-range, low-power radio, used here for the off-grid link |
