"""Group detections from different nodes into one sound, then decide how sure we are.

Levels:
  unconfirmed    only one node heard it (or nodes weren't synced)
  confirmed      2+ nodes heard it, within the time sound needs to travel between them
  likely_person  confirmed AND human-like: a voice or cough, or knocks that repeat
                 (or a knock the IMU also felt through the structure)
"""
from __future__ import annotations

import itertools
import math
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from .classify import SoundClass, classify
from .events import SoundEvent, StatusEvent, VibEvent
from .locate import Location, speed_of_sound, tdoa, two_node, zone

LEVELS = ("unconfirmed", "confirmed", "likely_person")


@dataclass
class Decision:
    id: int
    t_us: int
    level: str
    label: str
    confidence: float
    nodes: list
    members: list
    location: Location | None
    repeated: bool = False
    vib: bool = False
    reasons: list = field(default_factory=list)
    classes: list = field(default_factory=list)


class Validator:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.pos = {nid: (n["x_m"], n["y_m"]) for nid, n in cfg["nodes"].items()}
        v = cfg["validation"]
        self.margin = v["sync_margin_s"]
        self.hold = v["hold_s"]
        self.pending: list[SoundEvent] = []
        self.vibs: deque = deque(maxlen=200)
        self.history: deque = deque(maxlen=200)
        self.status: dict[int, StatusEvent] = {}
        self.last_seen_gw: dict[int, int] = {}
        self.now_us = 0
        self._next_id = 1
        self.temp_c = cfg["air"]["temperature_c"]
        self.rh = cfg["air"]["humidity_pct"]

    # ------------------------------------------------------------------ input
    def add(self, ev) -> None:
        self.now_us = max(self.now_us, ev.gw_us)
        self.last_seen_gw[ev.node] = ev.gw_us
        if isinstance(ev, SoundEvent):
            self.pending.append(ev)
            self.pending.sort(key=lambda e: e.t_us)
        elif isinstance(ev, VibEvent):
            self.vibs.append(ev)
        elif isinstance(ev, StatusEvent):
            self.status[ev.node] = ev
            if ev.has_env:
                self.temp_c, self.rh = ev.temp_c, ev.rh

    def tick(self, gw_now_us: int) -> None:
        """Advance 'now' without an event (keeps decisions flowing when the room is quiet)."""
        self.now_us = max(self.now_us, gw_now_us)

    @property
    def c(self) -> float:
        return speed_of_sound(self.temp_c, self.rh)

    # ------------------------------------------------------------------ grouping
    def _dist(self, a: int, b: int) -> float:
        pa, pb = self.pos.get(a), self.pos.get(b)
        if pa is None or pb is None:
            return 0.0
        return math.hypot(pa[0] - pb[0], pa[1] - pb[1])

    def _window_s(self) -> float:
        ids = list(self.pos)
        dmax = max((self._dist(a, b) for a, b in itertools.combinations(ids, 2)), default=0.0)
        return dmax / self.c + self.margin

    def _consistent(self, a: SoundEvent, b: SoundEvent) -> bool:
        return abs(a.t_us - b.t_us) / 1e6 <= self._dist(a.node, b.node) / self.c + self.margin

    def pop_decisions(self) -> list[Decision]:
        out = []
        window_us = int(self._window_s() * 1e6)
        hold_us = int(self.hold * 1e6)
        while self.pending and self.now_us - self.pending[0].t_us > window_us + hold_us:
            anchor = self.pending[0]
            if not anchor.synced:
                self.pending.pop(0)
                out.append(self._decide([anchor], note="node clock not synced"))
                continue
            members = [e for e in self.pending if e.synced and e.t_us - anchor.t_us <= window_us]
            earliest = {}
            for e in members:
                if e.node not in earliest or e.t_us < earliest[e.node].t_us:
                    earliest[e.node] = e
            group = [anchor] + [e for n, e in earliest.items() if n != anchor.node and self._consistent(anchor, e)]
            for e in group:
                self.pending.remove(e)
            # drop echoes: later detections from a node already in the group
            for e in [e for e in members if e not in group and e.node in {g.node for g in group}]:
                if e in self.pending and e.t_us - anchor.t_us <= window_us:
                    self.pending.remove(e)
            out.append(self._decide(group))
        return out

    # ------------------------------------------------------------------ decision
    def _decide(self, group: list[SoundEvent], note: str | None = None) -> Decision:
        th = self.cfg["classification"]
        group = sorted(group, key=lambda e: e.t_us)
        classes: list[SoundClass] = [classify(e, th) for e in group]
        best = max(range(len(group)), key=lambda i: group[i].snr)   # closest/loudest node decides
        cls = classes[best]
        nodes = [e.node for e in group]
        reasons = [f"{cls.label}: {cls.reason}"]
        if note:
            reasons.append(note)

        # location
        loc = None
        known = [e for e in group if e.node in self.pos]
        if len(known) >= 3:
            loc = tdoa([self.pos[e.node] for e in known], [e.t_s for e in known], self.c,
                       self.cfg["location"]["timing_sigma_s"])
        elif len(known) == 2:
            a, b = known
            loc = two_node(self.pos[a.node], self.pos[b.node], a.t_s, b.t_s, self.c)
        elif len(known) == 1:
            loc = zone(self.pos[known[0].node])

        level = "confirmed" if len(group) >= 2 else "unconfirmed"
        if level == "confirmed":
            reasons.append(f"heard by {len(group)} nodes within the travel-time window")
        else:
            reasons.append("only one node heard it")

        vib = any(abs(v.t_us - group[0].t_us) / 1e6 <= self.cfg["validation"]["vib_window_s"]
                  for v in self.vibs)
        repeated = self._repeated(group[0].t_us, cls.label, loc, nodes)
        if vib:
            reasons.append("vibration felt by an IMU at the same moment")
        if repeated:
            reasons.append("part of a repeated knock pattern")

        if level == "confirmed":
            if cls.label in ("voice", "cough"):
                level = "likely_person"
            elif cls.label == "knock_tap" and (repeated or vib):
                level = "likely_person"

        conf = cls.confidence
        if level == "confirmed":
            conf = min(0.95, conf + 0.1)
        if level == "likely_person":
            conf = min(0.99, conf + 0.2 + (0.05 if vib else 0) + (0.05 if repeated else 0))

        d = Decision(self._next_id, group[0].t_us, level, cls.label, round(conf, 2), nodes, group,
                     loc, repeated, vib, reasons, classes)
        self._next_id += 1
        self.history.append(d)
        return d

    def _repeated(self, t_us: int, label: str, loc: Location | None, nodes: list) -> bool:
        if label != "knock_tap":
            return False
        v = self.cfg["validation"]
        prev = [h for h in self.history if h.label == "knock_tap"
                and 0 < (t_us - h.t_us) / 1e6 <= v["repeat_window_s"]]
        for h in prev:
            gap = (t_us - h.t_us) / 1e6
            if not (v["repeat_min_interval_s"] <= gap <= v["repeat_max_interval_s"]):
                continue
            if loc is not None and h.location is not None:
                if math.hypot(loc.x_m - h.location.x_m, loc.y_m - h.location.y_m) <= v["same_place_m"]:
                    return True
            elif set(nodes) & set(h.nodes):
                return True
        return False

    # ------------------------------------------------------------------ health
    def node_health(self) -> dict[int, dict]:
        out = {}
        for nid in self.pos:
            st = self.status.get(nid)
            seen = self.last_seen_gw.get(nid)
            age = (self.now_us - seen) / 1e6 if seen else None
            out[nid] = dict(online=age is not None and age < 12.0, age_s=age,
                            synced=bool(st and st.synced),
                            temp_c=st.temp_c if st and st.has_env else None,
                            rh=st.rh if st and st.has_env else None,
                            moved=bool(st and st.moved), noise_floor=st.noise_floor if st else None)
        return out
