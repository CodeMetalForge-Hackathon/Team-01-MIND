"""Where the JSON lines come from: the gateway/LoRa receiver on USB, or a simulator."""
from __future__ import annotations

import json
import math
import queue
import random
import threading
import time


class SerialSource(threading.Thread):
    def __init__(self, port: str, out: queue.Queue, baud: int = 115200):
        super().__init__(daemon=True)
        self.port, self.out, self.baud = port, out, baud

    def run(self) -> None:
        import serial  # pyserial
        with serial.Serial(self.port, self.baud, timeout=1) as s:
            while True:
                line = s.readline()
                if line:
                    self.out.put(line.decode("utf-8", errors="replace"))


class SimSource(threading.Thread):
    """Plays a repeating scenario so the whole pipeline can be tested without hardware.

    Every ~26 s: a repeated knock pattern, a door slam near one node, a voice, a single
    knock, steady hum at one node, a cough, and a knock felt by an IMU.
    """

    def __init__(self, cfg: dict, out: queue.Queue, speed: float = 1.0, seed: int = 1):
        super().__init__(daemon=True)
        self.cfg, self.out, self.speed = cfg, out, speed
        self.rng = random.Random(seed)
        self.nodes = {nid: (n["x_m"], n["y_m"]) for nid, n in cfg["nodes"].items()}
        self.c = 331.4 + 0.6 * cfg["air"]["temperature_c"] + 0.0124 * cfg["air"]["humidity_pct"]
        self.seq = {nid: 0 for nid in self.nodes}
        self.t0 = time.monotonic()

    def gw_now(self) -> int:
        return int((time.monotonic() - self.t0) * self.speed * 1e6) + 10_000_000

    def _emit(self, d: dict) -> None:
        self.out.put(json.dumps(d))

    def _sound(self, nid, t_us, dur, rise, mod, peak):
        self.seq[nid] += 1
        self._emit(dict(type="sound", node=nid, seq=self.seq[nid], t_us=int(t_us), peak=int(peak), floor=8,
                        dur_ms=int(dur), rise_ms=round(rise, 1), mod_hz=round(mod, 1),
                        energy=int(peak * dur / 10), synced=1, rssi=-55,
                        gw_us=int(t_us + 5000 + dur * 1000), via="sim"))

    def _at_source(self, src, t_us, dur, rise, mod, heard_by=None, peak=900):
        for nid, p in self.nodes.items():
            if heard_by is not None and nid not in heard_by:
                continue
            d = math.hypot(src[0] - p[0], src[1] - p[1])
            arrival = t_us + d / self.c * 1e6 + self.rng.gauss(0, 150)
            self._sound(nid, arrival, dur * self.rng.uniform(0.9, 1.1), rise, mod,
                        peak / max(d, 0.3) * self.rng.uniform(0.8, 1.2))

    def run(self) -> None:
        script = [
            (2.0, "knock", (0.8, 1.2)), (2.6, "knock", (0.8, 1.2)), (3.2, "knock", (0.8, 1.2)),
            (6.0, "slam", None), (9.0, "voice", (1.8, 1.0)), (13.0, "knock", (1.2, 0.5)),
            (16.0, "hum", None), (19.0, "cough", (0.5, 0.8)), (22.0, "knock_vib", (0.4, 0.6)),
        ]
        period = 26.0
        last_status = -10.0
        cycle = 0
        while True:
            for when, kind, src in script:
                target = cycle * period + when
                while (time.monotonic() - self.t0) * self.speed < target:
                    sim_t = (time.monotonic() - self.t0) * self.speed
                    if sim_t - last_status >= 5.0:
                        last_status = sim_t
                        for nid in self.nodes:
                            self._emit(dict(type="status", node=nid, seq=0, uptime_s=int(sim_t), synced=1,
                                            has_env=1 if nid == 1 else 0, temp_c=22.0, rh=40.0,
                                            has_imu=1 if nid == 1 else 0, moved=0, tilt_deg=1.0,
                                            noise_floor=8, rssi=-50, gw_us=self.gw_now(), via="sim"))
                    time.sleep(0.02)
                t_us = self.gw_now()
                first = min(self.nodes)
                last = max(self.nodes)
                if kind == "knock":
                    self._at_source(src, t_us, 40, 1.0, 0.0)
                elif kind == "slam":
                    p = self.nodes[last]
                    self._at_source((p[0] + 0.2, p[1] + 0.2), t_us, 320, 2.0, 0.0, heard_by=[last], peak=1500)
                elif kind == "voice":
                    self._at_source(src, t_us, 900, 25.0, 4.5, peak=500)
                elif kind == "hum":
                    p = self.nodes[first]
                    self._at_source((p[0], p[1] + 0.3), t_us, 2000, 200.0, 0.5, heard_by=[first], peak=200)
                elif kind == "cough":
                    self._at_source(src, t_us, 300, 15.0, 1.0, peak=600)
                elif kind == "knock_vib":
                    self._at_source(src, t_us, 40, 1.0, 0.0)
                    self._emit(dict(type="vib", node=first, seq=0, t_us=int(t_us + 2000), peak_mg=120,
                                    synced=1, gw_us=int(t_us + 6000), via="sim"))
            cycle += 1
