"""Drop-and-Listen laptop software: validate, classify and locate sounds from sensor nodes."""
__version__ = "1.0.0"
