"""Send markers to ATAK as Cursor on Target (CoT) XML over UDP (default: ATAK multicast)."""
from __future__ import annotations

import datetime as dt
import math
import socket

M_PER_DEG_LAT = 111_320.0


def local_to_latlon(x_m: float, y_m: float, cfg: dict):
    b = math.radians(cfg["x_axis_bearing_deg"])
    east = x_m * math.sin(b) - y_m * math.cos(b)
    north = x_m * math.cos(b) + y_m * math.sin(b)
    lat = cfg["lat0"] + north / M_PER_DEG_LAT
    lon = cfg["lon0"] + east / (M_PER_DEG_LAT * math.cos(math.radians(cfg["lat0"])))
    return lat, lon


def cot_xml(uid: str, lat: float, lon: float, ce_m: float, callsign: str, remarks: str,
            cot_type: str = "a-u-G", stale_s: int = 600) -> str:
    now = dt.datetime.now(dt.timezone.utc)
    fmt = "%Y-%m-%dT%H:%M:%S.%fZ"
    t, stale = now.strftime(fmt), (now + dt.timedelta(seconds=stale_s)).strftime(fmt)
    remarks = remarks.replace("&", "and").replace("<", "").replace(">", "").replace('"', "'")
    callsign = callsign.replace('"', "'")
    return (f'<event version="2.0" uid="{uid}" type="{cot_type}" how="m-g" time="{t}" start="{t}" '
            f'stale="{stale}"><point lat="{lat:.7f}" lon="{lon:.7f}" hae="0" ce="{min(ce_m, 9999):.1f}" '
            f'le="9999999"/><detail><contact callsign="{callsign}"/><remarks>{remarks}</remarks>'
            f'</detail></event>')


class AtakSender:
    def __init__(self, cfg: dict):
        self.cfg = cfg["atak"]
        self.enabled = bool(self.cfg.get("enabled", False))
        self.sock = None
        if self.enabled:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)

    def _send(self, xml: str) -> None:
        if self.sock:
            try:
                self.sock.sendto(xml.encode(), (self.cfg["host"], int(self.cfg["port"])))
            except OSError as e:
                print(f"[atak] send failed: {e}")

    def send_decision(self, d) -> bool:
        if not self.enabled or d.level not in self.cfg.get("send_levels", []) or d.location is None:
            return False
        lat, lon = local_to_latlon(d.location.x_m, d.location.y_m, self.cfg)
        word = {"knock_tap": "KNOCK", "voice": "VOICE", "cough": "COUGH"}.get(d.label, d.label.upper())
        callsign = f"{word} person-likely {int(d.confidence * 100)}%"
        remarks = f"Drop-and-Listen: {len(d.nodes)} nodes. " + "; ".join(d.reasons)
        self._send(cot_xml(f"dnl-sound-{d.id}", lat, lon, d.location.radius_m, callsign, remarks))
        return True

    def send_nodes(self, nodes: dict) -> None:
        if not self.enabled or not self.cfg.get("publish_nodes", True):
            return
        for nid, n in nodes.items():
            lat, lon = local_to_latlon(n["x_m"], n["y_m"], self.cfg)
            self._send(cot_xml(f"dnl-node-{nid}", lat, lon, 1.0, n.get("name", f"DNL-{nid}"),
                               "Drop-and-Listen sensor node", cot_type="a-f-G", stale_s=180))
