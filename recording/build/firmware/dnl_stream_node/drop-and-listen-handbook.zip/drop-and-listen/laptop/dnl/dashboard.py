"""Live map: nodes, located sounds coloured by confidence level, node health and a log."""
from __future__ import annotations

import time
from collections import deque

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import Circle

COLORS = {"likely_person": "#d62728", "confirmed": "#ff7f0e", "unconfirmed": "#9a9a9a"}
SHOW_S = 60.0


class Dashboard:
    def __init__(self, cfg: dict, validator):
        self.cfg, self.val = cfg, validator
        self.recent = deque(maxlen=40)            # (wall time, decision)
        self.fig = plt.figure(figsize=(13, 7))
        self.fig.canvas.manager.set_window_title("Drop-and-Listen")
        gs = self.fig.add_gridspec(1, 2, width_ratios=[1.6, 1])
        self.ax = self.fig.add_subplot(gs[0, 0])
        self.tx = self.fig.add_subplot(gs[0, 1])
        xs = [n["x_m"] for n in cfg["nodes"].values()]
        ys = [n["y_m"] for n in cfg["nodes"].values()]
        self.lim = (min(xs) - 1.5, max(xs) + 1.5, min(ys) - 1.0, max(ys) + 3.0)

    def add(self, decisions) -> None:
        now = time.time()
        for d in decisions:
            self.recent.append((now, d))

    def draw(self) -> None:
        ax, tx = self.ax, self.tx
        ax.clear(); tx.clear(); tx.axis("off")
        health = self.val.node_health()
        now = time.time()
        for wall, d in self.recent:
            age = now - wall
            if age > SHOW_S or d.location is None:
                continue
            alpha = max(0.15, 1.0 - age / SHOW_S)
            col = COLORS[d.level]
            loc = d.location
            if loc.kind == "line" and loc.curve:
                cx, cy = zip(*loc.curve)
                ax.plot(cx, cy, color=col, lw=1.2, alpha=alpha * 0.8)
            if loc.kind == "point":
                ax.add_patch(Circle((loc.x_m, loc.y_m), loc.radius_m, color=col, alpha=alpha * 0.15))
            marker = "*" if d.level == "likely_person" else ("o" if d.level == "confirmed" else "x")
            ax.plot(loc.x_m, loc.y_m, marker, color=col, ms=16 if marker == "*" else 9, alpha=alpha)
            ax.annotate(f"#{d.id} {d.label}", (loc.x_m, loc.y_m), textcoords="offset points",
                        xytext=(6, 6), fontsize=8, color=col, alpha=alpha)
        for nid, n in self.cfg["nodes"].items():
            h = health.get(nid, {})
            col = "#2ca02c" if h.get("online") and h.get("synced") else ("#ff7f0e" if h.get("online") else "#555555")
            ax.plot(n["x_m"], n["y_m"], "s", color=col, ms=13)
            ax.annotate(n.get("name", f"DNL-{nid}"), (n["x_m"], n["y_m"]), textcoords="offset points",
                        xytext=(0, -18), ha="center", fontsize=9)
        x0, x1, y0, y1 = self.lim
        ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.set_aspect("equal"); ax.grid(alpha=0.3)
        ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
        ax.set_title("Red star: likely a person   Orange: confirmed sound   Grey x: one node only", fontsize=10)

        lines = [f"speed of sound {self.val.c:.1f} m/s", "", "NODES"]
        for nid, h in health.items():
            age = f"{h['age_s']:.0f}s ago" if h["age_s"] is not None else "never"
            env = f"  {h['temp_c']:.1f}C {h['rh']:.0f}%" if h["temp_c"] is not None else ""
            mv = "  MOVED" if h["moved"] else ""
            lines.append(f" {nid}: {'online' if h['online'] else 'OFFLINE'}  {'synced' if h['synced'] else 'not synced'}  {age}{env}{mv}")
        lines += ["", "LATEST"]
        for wall, d in list(self.recent)[-12:][::-1]:
            where = f"({d.location.x_m:.1f},{d.location.y_m:.1f})" if d.location else ""
            flags = ("R" if d.repeated else "") + ("V" if d.vib else "")
            lines.append(f" #{d.id:<3} {d.level:<13} {d.label:<9} n={','.join(map(str, d.nodes))} {where} {flags}")
        tx.text(0, 1, "\n".join(lines), va="top", family="monospace", fontsize=9)

    def run(self, pump) -> None:
        def update(_):
            self.add(pump())
            self.draw()
        self._anim = FuncAnimation(self.fig, update, interval=300, cache_frame_data=False)
        plt.tight_layout()
        plt.show()
