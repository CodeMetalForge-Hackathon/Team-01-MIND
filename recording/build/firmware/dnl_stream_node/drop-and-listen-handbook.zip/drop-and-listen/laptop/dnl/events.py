"""Parse the JSON lines printed by the gateway or the LoRa receiver."""
from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass
class SoundEvent:
    node: int
    t_us: int          # onset, gateway clock
    peak: float
    floor: float
    dur_ms: float
    rise_ms: float
    mod_hz: float
    energy: float
    synced: bool
    rssi: int
    gw_us: int         # gateway clock when received
    via: str = "espnow"

    @property
    def t_s(self) -> float:
        return self.t_us / 1e6

    @property
    def snr(self) -> float:
        return self.peak / max(self.floor, 1.0)


@dataclass
class StatusEvent:
    node: int
    uptime_s: int
    synced: bool
    has_env: bool
    temp_c: float
    rh: float
    has_imu: bool
    moved: bool
    tilt_deg: float
    noise_floor: float
    rssi: int
    gw_us: int
    via: str = "espnow"


@dataclass
class VibEvent:
    node: int
    t_us: int
    peak_mg: float
    synced: bool
    gw_us: int
    via: str = "espnow"


def parse_line(line: str | bytes):
    """Return a SoundEvent / StatusEvent / VibEvent, or None for anything else."""
    if isinstance(line, bytes):
        line = line.decode("utf-8", errors="replace")
    line = line.strip()
    if not line.startswith("{"):
        return None
    try:
        d = json.loads(line)
    except json.JSONDecodeError:
        return None
    kind = d.get("type")
    try:
        if kind == "sound":
            return SoundEvent(node=int(d["node"]), t_us=int(d["t_us"]), peak=float(d["peak"]),
                              floor=float(d["floor"]), dur_ms=float(d["dur_ms"]),
                              rise_ms=float(d["rise_ms"]), mod_hz=float(d["mod_hz"]),
                              energy=float(d["energy"]), synced=bool(d["synced"]),
                              rssi=int(d.get("rssi", 0)), gw_us=int(d["gw_us"]),
                              via=d.get("via", "espnow"))
        if kind == "status":
            return StatusEvent(node=int(d["node"]), uptime_s=int(d["uptime_s"]), synced=bool(d["synced"]),
                               has_env=bool(d["has_env"]), temp_c=float(d["temp_c"]), rh=float(d["rh"]),
                               has_imu=bool(d["has_imu"]), moved=bool(d["moved"]),
                               tilt_deg=float(d["tilt_deg"]), noise_floor=float(d["noise_floor"]),
                               rssi=int(d.get("rssi", 0)), gw_us=int(d["gw_us"]),
                               via=d.get("via", "espnow"))
        if kind == "vib":
            return VibEvent(node=int(d["node"]), t_us=int(d["t_us"]), peak_mg=float(d["peak_mg"]),
                            synced=bool(d["synced"]), gw_us=int(d["gw_us"]), via=d.get("via", "espnow"))
    except (KeyError, ValueError, TypeError):
        return None
    return None
