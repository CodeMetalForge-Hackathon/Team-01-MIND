"""Where did the sound come from?

1 node:  zone around that node.
2 nodes: the time gap fixes how much nearer the sound was to one node -> a curve (hyperbola).
         We report the point where that curve crosses the line between the nodes, with a
         wide uncertainty, plus the curve itself for the map.
3+ nodes: least-squares TDOA position with an uncertainty circle.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


def speed_of_sound(temp_c: float, rh_pct: float = 50.0) -> float:
    """Air, m/s."""
    return 331.4 + 0.6 * temp_c + 0.0124 * rh_pct


@dataclass
class Location:
    kind: str                     # "zone", "line" (2 nodes) or "point" (3+ nodes)
    x_m: float
    y_m: float
    radius_m: float               # uncertainty (95 % for "point", rough for others)
    curve: list = field(default_factory=list)   # [(x, y), ...] hyperbola for 2 nodes


def zone(pos) -> Location:
    return Location("zone", float(pos[0]), float(pos[1]), 1.0)


def hyperbola_points(p1, p2, dd: float, reach: float = 6.0, n: int = 80):
    """Points p with |p - p1| - |p - p2| = dd (the branch nearer the closer node)."""
    p1, p2 = np.asarray(p1, float), np.asarray(p2, float)
    L = float(np.hypot(*(p2 - p1)))
    a = min(abs(dd) / 2.0, L / 2.0 * 0.999)
    c = L / 2.0
    b = math.sqrt(max(c * c - a * a, 1e-9))
    axis = (p2 - p1) / L
    normal = np.array([-axis[1], axis[0]])
    mid = (p1 + p2) / 2.0
    sign = 1.0 if dd > 0 else -1.0             # dd > 0: farther from p1 -> branch toward p2
    tmax = math.asinh(reach / b) if b > 1e-6 else 0.0
    pts = []
    for t in np.linspace(-tmax, tmax, n):
        local = sign * a * math.cosh(t) * axis + b * math.sinh(t) * normal
        pts.append(tuple((mid + local).tolist()))
    return pts


def two_node(p1, p2, t1_s: float, t2_s: float, c: float) -> Location:
    p1, p2 = np.asarray(p1, float), np.asarray(p2, float)
    L = float(np.hypot(*(p2 - p1)))
    dd = float(np.clip(c * (t1_s - t2_s), -L, L))   # d1 - d2
    s = (L + dd) / 2.0                              # distance from p1 along the baseline
    xy = p1 + (p2 - p1) / L * s
    return Location("line", float(xy[0]), float(xy[1]), max(L / 2.0, 1.0), hyperbola_points(p1, p2, dd))


def tdoa(positions, times_s, c: float, timing_sigma_s: float = 5e-4) -> Location | None:
    """Least-squares position from 3+ arrival times (Gauss-Newton, several starts)."""
    P = np.asarray(positions, float)
    t = np.asarray(times_s, float)
    t = t - t.min()
    if len(t) < 3:
        return None
    centroid = P.mean(axis=0)
    span = max(float(np.ptp(P[:, 0])), float(np.ptp(P[:, 1])), 1.0)
    best = None
    for start in [centroid] + [centroid + span * np.array(v) for v in ((1, 0), (-1, 0), (0, 1), (0, -1))]:
        x = np.array([start[0], start[1], float(np.min(c * t - np.hypot(*(P - start).T)))])
        for _ in range(30):
            dx, dy = x[0] - P[:, 0], x[1] - P[:, 1]
            r = np.maximum(np.hypot(dx, dy), 1e-9)
            res = c * t - x[2] - r
            J = np.column_stack([-dx / r, -dy / r, -np.ones_like(r)])
            try:
                step = np.linalg.lstsq(J, -res, rcond=None)[0]
            except np.linalg.LinAlgError:
                break
            x = x + step
            if np.linalg.norm(step[:2]) < 1e-5:
                break
        dx, dy = x[0] - P[:, 0], x[1] - P[:, 1]
        r = np.maximum(np.hypot(dx, dy), 1e-9)
        cost = float(np.sum((c * t - x[2] - r) ** 2))
        key = (round(cost, 8), float(np.hypot(*(x[:2] - centroid))))
        if best is None or key < best[0]:
            best = (key, x, r, dx, dy)
    _, x, r, dx, dy = best
    J = np.column_stack([-dx / r, -dy / r, -np.ones_like(r)])
    try:
        cov = (c * timing_sigma_s) ** 2 * np.linalg.inv(J.T @ J)[:2, :2]
        radius = float(math.sqrt(5.991 * max(np.linalg.eigvalsh(cov).max(), 0.0)))
    except np.linalg.LinAlgError:
        radius = 5.0
    return Location("point", float(x[0]), float(x[1]), min(radius, 50.0))
