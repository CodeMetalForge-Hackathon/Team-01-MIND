"""Log every raw line and every decision to data/runs/<timestamp>/ (git-ignored)."""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path


class RunLogger:
    def __init__(self, root: str | Path = "data/runs"):
        self.dir = Path(root) / dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.dir.mkdir(parents=True, exist_ok=True)
        self.raw = open(self.dir / "raw.jsonl", "a", buffering=1)
        self.dec_file = open(self.dir / "decisions.csv", "a", newline="", buffering=1)
        self.dec = csv.writer(self.dec_file)
        self.dec.writerow(["id", "t_s", "level", "label", "confidence", "nodes", "x_m", "y_m",
                           "radius_m", "loc_kind", "repeated", "vib", "reasons",
                           "dur_ms", "rise_ms", "mod_hz", "snr"])

    def line(self, text: str) -> None:
        self.raw.write(text.rstrip() + "\n")

    def decision(self, d) -> None:
        m = max(d.members, key=lambda e: e.snr)
        loc = d.location
        self.dec.writerow([d.id, f"{d.t_us / 1e6:.6f}", d.level, d.label, d.confidence,
                           " ".join(map(str, d.nodes)),
                           f"{loc.x_m:.3f}" if loc else "", f"{loc.y_m:.3f}" if loc else "",
                           f"{loc.radius_m:.2f}" if loc else "", loc.kind if loc else "",
                           int(d.repeated), int(d.vib), " | ".join(d.reasons),
                           m.dur_ms, m.rise_ms, m.mod_hz, f"{m.snr:.1f}"])

    def close(self) -> None:
        self.raw.close()
        self.dec_file.close()
