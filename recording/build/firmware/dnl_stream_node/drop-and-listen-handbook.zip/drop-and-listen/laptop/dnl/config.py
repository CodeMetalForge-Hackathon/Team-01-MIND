"""Load config.yaml."""
from __future__ import annotations

from pathlib import Path

import yaml

DEFAULT = Path(__file__).resolve().parents[1] / "config.yaml"


def load_config(path: str | Path | None = None) -> dict:
    cfg = yaml.safe_load(Path(path or DEFAULT).read_text())
    cfg["nodes"] = {int(k): v for k, v in cfg["nodes"].items()}
    return cfg
