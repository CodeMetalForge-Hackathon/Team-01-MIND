"""Run the command post.

    python -m dnl.main --port COM12          # gateway or LoRa receiver on USB
    python -m dnl.main --sim                 # no hardware: simulated nodes
    python -m dnl.main --sim --no-dash       # text only
Options: --config path, --no-atak, --speed 2 (sim only), --logdir data/runs
"""
from __future__ import annotations

import argparse
import queue
import time

from .atak import AtakSender
from .config import load_config
from .events import parse_line
from .logger import RunLogger
from .sources import SerialSource, SimSource
from .validate import Validator


def describe(d) -> str:
    where = f"at ({d.location.x_m:.2f}, {d.location.y_m:.2f}) ±{d.location.radius_m:.1f} m [{d.location.kind}]" \
        if d.location else ""
    return (f"#{d.id:<3} {d.level.upper():<14} {d.label:<9} conf {d.confidence:.2f}  nodes {d.nodes} {where}\n"
            f"      " + " | ".join(d.reasons))


def main() -> None:
    ap = argparse.ArgumentParser(description="Drop-and-Listen command post")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--port", help="serial port of the gateway or LoRa receiver, e.g. COM12")
    src.add_argument("--sim", action="store_true", help="simulated nodes, no hardware")
    ap.add_argument("--config", default=None)
    ap.add_argument("--no-dash", action="store_true")
    ap.add_argument("--no-atak", action="store_true")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--logdir", default="data/runs")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.no_atak:
        cfg["atak"]["enabled"] = False
    q: queue.Queue = queue.Queue()
    source = SimSource(cfg, q, speed=args.speed) if args.sim else SerialSource(args.port, q)
    source.start()

    val = Validator(cfg)
    atak = AtakSender(cfg)
    log = RunLogger(args.logdir)
    state = {"offset_us": None, "last_nodes": 0.0}
    print(f"logging to {log.dir}")

    def pump():
        while True:
            try:
                line = q.get_nowait()
            except queue.Empty:
                break
            log.line(line)
            ev = parse_line(line)
            if ev is None:
                if '"gw_start"' in line or '"lora_rx_start"' in line or '"error"' in line:
                    print("[device]", line.strip())
                continue
            state["offset_us"] = ev.gw_us - int(time.monotonic() * 1e6)
            val.add(ev)
        if state["offset_us"] is not None:
            val.tick(int(time.monotonic() * 1e6) + state["offset_us"])
        decisions = val.pop_decisions()
        for d in decisions:
            log.decision(d)
            sent = atak.send_decision(d)
            print(describe(d) + ("\n      -> sent to ATAK" if sent else ""))
        if time.time() - state["last_nodes"] > 60:
            state["last_nodes"] = time.time()
            atak.send_nodes(cfg["nodes"])
        return decisions

    try:
        if args.no_dash:
            while True:
                pump()
                time.sleep(0.1)
        else:
            from .dashboard import Dashboard
            Dashboard(cfg, val).run(pump)
    except KeyboardInterrupt:
        pass
    finally:
        log.close()


if __name__ == "__main__":
    main()
