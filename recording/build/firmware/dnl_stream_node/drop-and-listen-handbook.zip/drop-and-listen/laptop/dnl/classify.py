"""Classify one sound from the features the node measured.

The Grove sensor gives a one-sided loudness signal, so the features are about shape in time:
  rise_ms  onset to peak     knocks: a few ms;  voices and coughs: slower
  dur_ms   how long it lasts knocks: short;     voices: longer
  mod_hz   loudness ups and downs per second: speech has a syllable rhythm of ~3-8 Hz
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .events import SoundEvent

HUMAN_LABELS = {"knock_tap", "voice", "cough"}


@dataclass
class SoundClass:
    label: str          # knock_tap, voice, cough, impact, steady, other
    confidence: float   # 0-1
    human_candidate: bool
    reason: str


def classify(ev: SoundEvent, th: dict) -> SoundClass:
    d, r, m = ev.dur_ms, ev.rise_ms, ev.mod_hz
    loud = min(1.0, math.log10(max(ev.snr, 1.0)) / 2.0)     # 0 at snr 1, 1 at snr 100
    conf = round(0.5 + 0.45 * loud, 2)

    if d >= th["steady_min_dur_ms"] and m < th["steady_max_mod_hz"]:
        return SoundClass("steady", conf, False, f"long ({d:.0f} ms) and steady: machinery or hum")
    if r <= th["knock_max_rise_ms"] and d <= th["knock_max_dur_ms"]:
        return SoundClass("knock_tap", conf, True, f"sharp start ({r:.1f} ms) and short ({d:.0f} ms)")
    if r <= th["knock_max_rise_ms"]:
        return SoundClass("impact", conf, False, f"sharp start but rings long ({d:.0f} ms): slam or drop")
    if th["voice_min_dur_ms"] <= d <= th["voice_max_dur_ms"] and th["voice_min_mod_hz"] <= m <= th["voice_max_mod_hz"]:
        return SoundClass("voice", conf, True, f"{d:.0f} ms with a {m:.1f} Hz syllable rhythm")
    if th["cough_min_dur_ms"] <= d <= th["cough_max_dur_ms"] and m < th["voice_min_mod_hz"]:
        return SoundClass("cough", round(conf * 0.8, 2), True, f"short burst ({d:.0f} ms), slower start")
    return SoundClass("other", round(conf * 0.6, 2), False, "doesn't match a known pattern")
