from dnl.classify import classify
from dnl.config import load_config
from dnl.events import SoundEvent

TH = load_config()["classification"]


def ev(dur, rise, mod, peak=800, floor=8):
    return SoundEvent(node=1, t_us=0, peak=peak, floor=floor, dur_ms=dur, rise_ms=rise, mod_hz=mod,
                      energy=0, synced=True, rssi=-50, gw_us=0)


def test_knock():
    assert classify(ev(40, 1.0, 0), TH).label == "knock_tap"


def test_impact():
    assert classify(ev(320, 2.0, 0), TH).label == "impact"


def test_voice():
    c = classify(ev(900, 25, 4.5), TH)
    assert c.label == "voice" and c.human_candidate


def test_cough():
    assert classify(ev(300, 15, 1.0), TH).label == "cough"


def test_steady():
    assert classify(ev(2000, 200, 0.5), TH).label == "steady"
