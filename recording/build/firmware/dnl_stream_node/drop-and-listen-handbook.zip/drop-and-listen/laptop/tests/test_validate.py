import math

from dnl.config import load_config
from dnl.events import SoundEvent, VibEvent
from dnl.locate import speed_of_sound
from dnl.validate import Validator

CFG = load_config()
C = speed_of_sound(CFG["air"]["temperature_c"], CFG["air"]["humidity_pct"])
POS = {n: (v["x_m"], v["y_m"]) for n, v in CFG["nodes"].items()}


def hear(src, t0_s, dur=40, rise=1.0, mod=0.0, nodes=(1, 2)):
    out = []
    for n in nodes:
        d = math.hypot(src[0] - POS[n][0], src[1] - POS[n][1])
        t = int((t0_s + d / C) * 1e6)
        out.append(SoundEvent(node=n, t_us=t, peak=800, floor=8, dur_ms=dur, rise_ms=rise, mod_hz=mod,
                              energy=0, synced=True, rssi=-50, gw_us=t + 5000))
    return out


def run(events, end_s):
    v = Validator(CFG)
    for e in events:
        v.add(e)
    v.tick(int(end_s * 1e6))
    return v.pop_decisions()


def test_two_nodes_confirm():
    ds = run(hear((1.0, 1.0), 10.0), 12.0)
    assert len(ds) == 1 and ds[0].level == "confirmed" and ds[0].nodes == [1, 2]


def test_one_node_unconfirmed():
    ds = run(hear((0.2, 0.2), 10.0, nodes=(1,)), 12.0)
    assert len(ds) == 1 and ds[0].level == "unconfirmed"


def test_impossible_gap_splits():
    a = hear((1.0, 1.0), 10.0, nodes=(1,))
    b = hear((1.0, 1.0), 10.5, nodes=(2,))      # 0.5 s later: can't be the same sound
    ds = run(a + b, 13.0)
    assert len(ds) == 2 and all(d.level == "unconfirmed" for d in ds)


def test_repeated_knocks_become_likely_person():
    evs = hear((0.8, 1.2), 10.0) + hear((0.8, 1.2), 10.6) + hear((0.8, 1.2), 11.2)
    ds = run(evs, 14.0)
    assert [d.level for d in ds] == ["confirmed", "likely_person", "likely_person"]


def test_voice_is_likely_person():
    ds = run(hear((1.8, 1.0), 10.0, dur=900, rise=25, mod=4.5), 13.0)
    assert ds[0].label == "voice" and ds[0].level == "likely_person"


def test_knock_with_vibration_is_likely_person():
    evs = hear((0.4, 0.6), 10.0)
    vib = VibEvent(node=1, t_us=int(10.002e6), peak_mg=120, synced=True, gw_us=int(10.006e6))
    ds = run(evs + [vib], 12.0)
    assert ds[0].vib and ds[0].level == "likely_person"


def test_two_node_location_on_correct_side():
    ds = run(hear((0.5, 0.0), 10.0), 12.0)     # right next to node 1
    assert ds[0].location.x_m < 1.25
