// espnow_test: flash on EVERY board. Each one broadcasts a hello per second and prints
// everything it hears. All boards must use 2.4 GHz channel 1.
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "soc/soc_caps.h"

static const uint8_t BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static uint32_t counter = 0;

void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  char msg[64] = {0};
  memcpy(msg, data, min(len, 63));
  const uint8_t *m = info->src_addr;
  Serial.printf("heard %02X:%02X:%02X:%02X:%02X:%02X  rssi %d  \"%s\"\n",
                m[0], m[1], m[2], m[3], m[4], m[5], info->rx_ctrl->rssi, msg);
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
#ifdef SOC_WIFI_SUPPORT_5G
  esp_wifi_set_band_mode(WIFI_BAND_MODE_2G_ONLY);   // ESP32-C5: stay on 2.4 GHz like the others
#endif
  esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE);
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    while (true) delay(1000);
  }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST, 6);
  peer.channel = 1;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
  Serial.printf("I am %s\n", WiFi.macAddress().c_str());
}

void loop() {
  char msg[48];
  snprintf(msg, sizeof(msg), "hello %lu from %s", (unsigned long)counter++, WiFi.macAddress().c_str());
  esp_now_send(BROADCAST, (const uint8_t *)msg, strlen(msg) + 1);
  delay(1000);
}
