// config.h for the field gateway (LILYGO LoRa32, or any ESP32 for the USB-only version).
#pragma once

#define ESPNOW_CHANNEL 1           // must match the nodes
#define BEACON_PERIOD_MS 1000      // time-sync beacon

#define ENABLE_LORA 1              // 0 = USB only (any ESP32 works as gateway)

// LoRa radio pins: LILYGO T3 LoRa32 V1.6.x. TODO(hardware): check your board version.
#define LORA_SCK   5
#define LORA_MISO  19
#define LORA_MOSI  27
#define LORA_CS    18
#define LORA_RST   23
#define LORA_DIO0  26
#define LORA_DIO1  33

#define LORA_FREQ_MHZ 915.0        // US band
#define LORA_BW_KHZ   125.0
#define LORA_SF       7
#define LORA_CR       5
#define LORA_POWER_DBM 17
