// detector.h: finds sounds in the Grove signal and measures features for classification.
// One trigger for every kind of sound (knock, voice, cough...); the features decide later:
//   rise_ms  onset to peak: knocks rise in a few ms, voices more slowly
//   dur_ms   how long the sound lasts
//   mod_hz   loudness ups and downs per second: speech has a syllable rhythm of ~3-8 Hz
#pragma once
#include <Arduino.h>
#include <math.h>
#include "config.h"

struct SoundFeatures {
  int64_t onsetLocalUs;
  float peak, floor, durMs, riseMs, modHz, energy;
};

class SoundDetector {
 public:
  void begin(float fs) {
    fs_ = fs;
    aFast_ = 1.0f - expf(-1.0f / (fs * 0.0007f));   // envelope, ~0.7 ms
    aSlow_ = 1.0f - expf(-1.0f / (fs * 0.015f));    // slow envelope, ~15 ms (syllables)
    aFloor_ = 1.0f - expf(-1.0f / (fs * 1.0f));     // noise floor, ~1 s
    aBase_ = 1.0f - expf(-1.0f / (fs * 1.0f));      // resting level, ~1 s
    decimN_ = (int)(fs / 100);                      // slow envelope stored every 10 ms
  }

  float noiseFloor() const { return floor_; }

  // Feed one sample with its local time. Returns true when a sound has ended (features in *out).
  bool process(int raw, int64_t t, SoundFeatures *out) {
    if (base_ < 0) base_ = raw;
    float a = fabsf(raw - base_);
    env_ += aFast_ * (a - env_);
    envSlow_ += aSlow_ * (env_ - envSlow_);
    histEnv_[histPos_] = env_;
    histT_[histPos_] = t;
    histPos_ = (histPos_ + 1) % HIST;

    if (!active_) {
      base_ += aBase_ * (raw - base_);
      float thr = fmaxf(K_TRIGGER * floor_, ABS_MIN_COUNTS);
      if (t >= refractoryUntil_ && env_ > thr) {
        onset_ = t;
        for (int k = 1; k < HIST; k++) {              // walk back to the start of the rise
          int idx = (histPos_ - 1 - k + HIST) % HIST;
          if (histEnv_[idx] < 0.3f * thr) break;
          onset_ = histT_[idx];
        }
        active_ = true;
        peak_ = env_; peakT_ = t; lastLoud_ = t;
        floorAtOnset_ = floor_; energy_ = 0; slowN_ = 0; decim_ = 0;
      } else if (env_ < thr) {
        floor_ += aFloor_ * (env_ - floor_);
        if (floor_ < 1.0f) floor_ = 1.0f;
      }
      return false;
    }

    energy_ += env_;
    if (env_ > peak_) { peak_ = env_; peakT_ = t; }
    if (envSlow_ > 1.8f * floorAtOnset_) lastLoud_ = t;
    if (++decim_ >= decimN_) { decim_ = 0; if (slowN_ < SLOW_MAX) slow_[slowN_++] = envSlow_; }

    bool ended = (t - lastLoud_) > 150000 || (t - onset_) > 2000000;
    if (!ended) return false;

    active_ = false;
    refractoryUntil_ = t + 120000;
    out->onsetLocalUs = onset_;
    out->peak = peak_;
    out->floor = floorAtOnset_;
    out->durMs = (lastLoud_ - onset_) / 1000.0f;
    out->riseMs = (peakT_ - onset_) / 1000.0f;
    int peaks = out->durMs > 250 ? countPeaks_() : 0;
    out->modHz = peaks >= 2 ? peaks / (out->durMs / 1000.0f) : 0.0f;   // one burst = no rhythm
    out->energy = energy_ / fs_ * 1000.0f;
    return true;
  }

 private:
  static const int HIST = 64;       // 6.4 ms at 10 kHz
  static const int SLOW_MAX = 220;  // 2.2 s at one point per 10 ms
  float fs_ = 10000, aFast_ = 0, aSlow_ = 0, aFloor_ = 0, aBase_ = 0;
  float base_ = -1, env_ = 0, envSlow_ = 0, floor_ = 5;
  float histEnv_[HIST];
  int64_t histT_[HIST];
  int histPos_ = 0;
  bool active_ = false;
  int64_t onset_ = 0, peakT_ = 0, lastLoud_ = 0, refractoryUntil_ = 0;
  float peak_ = 0, floorAtOnset_ = 5, energy_ = 0;
  float slow_[SLOW_MAX];
  int slowN_ = 0, decim_ = 0, decimN_ = 100;

  int countPeaks_() {
    float mx = 0;
    for (int i = 0; i < slowN_; i++) mx = fmaxf(mx, slow_[i]);
    if (mx <= 0 || slowN_ < 3) return 0;
    float hyst = 0.25f * mx, ext = slow_[0];
    bool rising = true;
    int peaks = 0;
    for (int i = 1; i < slowN_; i++) {
      float v = slow_[i];
      if (rising) {
        if (v > ext) ext = v;
        else if (ext - v > hyst) { if (ext > 0.35f * mx) peaks++; rising = false; ext = v; }
      } else {
        if (v < ext) ext = v;
        else if (v - ext > hyst) { rising = true; ext = v; }
      }
    }
    return peaks;
  }
};
