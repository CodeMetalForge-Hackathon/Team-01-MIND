// gateway: the field gateway.
//  - broadcasts the time-sync beacon every second (its clock is the shared timeline)
//  - receives node packets over ESP-NOW
//  - prints each one as a JSON line on USB (laptop can plug in here directly)
//  - forwards each one over LoRa to the command-post receiver (lora_rx), if enabled
// Board: LILYGO LoRa32 = "ESP32 Dev Module" (or TTGO LoRa32 entry). Library: RadioLib.
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "config.h"
#include "protocol.h"
#if ENABLE_LORA
#include <SPI.h>
#include <RadioLib.h>
SX1276 radio = new Module(LORA_CS, LORA_DIO0, LORA_RST, LORA_DIO1);
bool loraOk = false;
#endif

static const uint8_t BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

struct RxItem { int8_t rssi; int64_t gwUs; uint8_t len; uint8_t data[64]; };
static QueueHandle_t rxQueue;
static uint16_t beaconSeq = 0;
static uint32_t received = 0, forwarded = 0;

static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  RxItem item;
  item.gwUs = esp_timer_get_time();
  if (len <= 0 || len > (int)sizeof(item.data)) return;
  item.rssi = info->rx_ctrl->rssi;
  item.len = len;
  memcpy(item.data, data, len);
  xQueueSend(rxQueue, &item, 0);
}

static void sendBeacon() {
  PktBeacon b;
  b.h.magic = DNL_MAGIC; b.h.ver = DNL_VER; b.h.type = PKT_BEACON; b.h.node = 0;
  b.h.seq = beaconSeq++;
  b.gw_time_us = esp_timer_get_time();
  esp_now_send(BROADCAST, (const uint8_t *)&b, sizeof(b));
}

void setup() {
  Serial.begin(115200);
  delay(500);
  rxQueue = xQueueCreate(32, sizeof(RxItem));

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  if (esp_now_init() != ESP_OK) {
    Serial.println("{\"type\":\"error\",\"msg\":\"esp-now init failed\"}");
    while (true) delay(1000);
  }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);

#if ENABLE_LORA
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_CS);
  int st = radio.begin(LORA_FREQ_MHZ, LORA_BW_KHZ, LORA_SF, LORA_CR,
                       RADIOLIB_SX127X_SYNC_WORD, LORA_POWER_DBM, 8, 0);
  loraOk = (st == RADIOLIB_ERR_NONE);
  Serial.printf("{\"type\":\"gw_start\",\"mac\":\"%s\",\"lora\":%s,\"lora_code\":%d}\n",
                WiFi.macAddress().c_str(), loraOk ? "true" : "false", st);
#else
  Serial.printf("{\"type\":\"gw_start\",\"mac\":\"%s\",\"lora\":false}\n", WiFi.macAddress().c_str());
#endif
}

void loop() {
  static uint32_t lastBeacon = 0;
  if (millis() - lastBeacon >= BEACON_PERIOD_MS) { lastBeacon = millis(); sendBeacon(); }

  RxItem item;
  while (xQueueReceive(rxQueue, &item, 0) == pdTRUE) {
    received++;
    char json[384];
    if (dnl_to_json(item.data, item.len, item.rssi, item.gwUs, "espnow", json, sizeof(json)) > 0) {
      Serial.println(json);
    }
#if ENABLE_LORA
    if (loraOk) {
      // LoRa payload: [rssi int8][gateway time int64][original ESP-NOW packet]
      uint8_t out[80];
      out[0] = (uint8_t)item.rssi;
      memcpy(out + 1, &item.gwUs, 8);
      memcpy(out + 9, item.data, item.len);
      if (radio.transmit(out, 9 + item.len) == RADIOLIB_ERR_NONE) forwarded++;
    }
#endif
    if (millis() - lastBeacon >= BEACON_PERIOD_MS) { lastBeacon = millis(); sendBeacon(); }
  }

  static uint32_t lastStats = 0;
  if (millis() - lastStats >= 10000) {
    lastStats = millis();
    Serial.printf("{\"type\":\"gw_stats\",\"received\":%lu,\"forwarded\":%lu,\"gw_us\":%lld}\n",
                  (unsigned long)received, (unsigned long)forwarded, (long long)esp_timer_get_time());
  }
}
