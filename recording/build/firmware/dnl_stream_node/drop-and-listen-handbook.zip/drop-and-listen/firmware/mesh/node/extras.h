// extras.h: optional I2C sensors on the node, auto-detected at boot.
//   Temp & humidity: DHT20 / AHT20 at 0x38 (Grove Temperature & Humidity v2.0)
//   IMU: MPU6050 family (0x68/0x69: MPU6050, MPU6500, ICM20600...) or LSM6DS3 (0x6A/0x6B)
// The IMU gives two things: "node moved/tilted" for the status, and structure vibration
// events (a knock felt through the floor) as an extra vote for "this is a person".
// XIAO ESP32-C5 I2C pins: D4 = SDA, D5 = SCL (Wire.begin() uses them by default).
#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <math.h>
#include "config.h"

struct Extras {
  volatile bool hasEnv = false, hasImu = false, moved = false;
  volatile float tempC = NAN, rh = NAN, tiltDeg = 0;
};

typedef void (*VibCallback)(int64_t localUs, uint16_t peakMg);

namespace ext {

enum ImuType { IMU_NONE, IMU_MPU, IMU_LSM };
static ImuType imuType = IMU_NONE;
static uint8_t imuAddr = 0;
static Extras *state = nullptr;
static VibCallback onVib = nullptr;

static bool present(uint8_t a) {
  Wire.beginTransmission(a);
  return Wire.endTransmission() == 0;
}

static bool readRegs(uint8_t a, uint8_t reg, uint8_t *buf, uint8_t n) {
  Wire.beginTransmission(a);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(a, n) != n) return false;
  for (uint8_t i = 0; i < n; i++) buf[i] = Wire.read();
  return true;
}

static void writeReg(uint8_t a, uint8_t reg, uint8_t v) {
  Wire.beginTransmission(a);
  Wire.write(reg);
  Wire.write(v);
  Wire.endTransmission();
}

static bool initImu() {
  const uint8_t mpuAddrs[] = {0x68, 0x69};
  for (uint8_t a : mpuAddrs) {
    uint8_t who = 0xFF;
    if (present(a) && readRegs(a, 0x75, &who, 1) && who != 0xFF && who != 0x00) {
      writeReg(a, 0x6B, 0x00);  // wake up
      writeReg(a, 0x1C, 0x00);  // accelerometer +-2 g
      imuType = IMU_MPU; imuAddr = a;
      return true;
    }
  }
  const uint8_t lsmAddrs[] = {0x6A, 0x6B};
  for (uint8_t a : lsmAddrs) {
    uint8_t who = 0xFF;
    if (present(a) && readRegs(a, 0x0F, &who, 1) && (who == 0x69 || who == 0x6A || who == 0x6C)) {
      writeReg(a, 0x10, 0x60);  // accelerometer 416 Hz, +-2 g
      imuType = IMU_LSM; imuAddr = a;
      return true;
    }
  }
  return false;
}

static bool readAccelG(float &x, float &y, float &z) {
  uint8_t b[6];
  if (imuType == IMU_MPU) {
    if (!readRegs(imuAddr, 0x3B, b, 6)) return false;
    x = (int16_t)(b[0] << 8 | b[1]) / 16384.0f;
    y = (int16_t)(b[2] << 8 | b[3]) / 16384.0f;
    z = (int16_t)(b[4] << 8 | b[5]) / 16384.0f;
    return true;
  }
  if (imuType == IMU_LSM) {
    if (!readRegs(imuAddr, 0x28, b, 6)) return false;
    x = (int16_t)(b[1] << 8 | b[0]) * 0.000061f;
    y = (int16_t)(b[3] << 8 | b[2]) * 0.000061f;
    z = (int16_t)(b[5] << 8 | b[4]) * 0.000061f;
    return true;
  }
  return false;
}

static bool initEnv() {
  if (!present(0x38)) return false;
  delay(100);
  uint8_t st = 0;
  Wire.requestFrom((uint8_t)0x38, (uint8_t)1);
  if (Wire.available()) st = Wire.read();
  if ((st & 0x08) == 0) {          // not calibrated: send init command (AHT20)
    Wire.beginTransmission(0x38);
    Wire.write(0xBE); Wire.write(0x08); Wire.write(0x00);
    Wire.endTransmission();
    delay(10);
  }
  return true;
}

static bool readEnv(float &tC, float &rh) {
  Wire.beginTransmission(0x38);
  Wire.write(0xAC); Wire.write(0x33); Wire.write(0x00);
  if (Wire.endTransmission() != 0) return false;
  delay(85);
  uint8_t b[7];
  if (Wire.requestFrom((uint8_t)0x38, (uint8_t)7) != 7) return false;
  for (int i = 0; i < 7; i++) b[i] = Wire.read();
  if (b[0] & 0x80) return false;   // still busy
  uint32_t hRaw = ((uint32_t)b[1] << 12) | ((uint32_t)b[2] << 4) | (b[3] >> 4);
  uint32_t tRaw = (((uint32_t)b[3] & 0x0F) << 16) | ((uint32_t)b[4] << 8) | b[5];
  rh = hRaw * 100.0f / 1048576.0f;
  tC = tRaw * 200.0f / 1048576.0f - 50.0f;
  return true;
}

static void task(void *) {
  Wire.begin();
  Wire.setClock(400000);
  if (ENABLE_ENV) state->hasEnv = initEnv();
  if (ENABLE_IMU) state->hasImu = initImu();
#if DEBUG_PRINT
  Serial.printf("[extras] temp/humidity: %s, IMU: %s\n", state->hasEnv ? "found" : "none",
                imuType == IMU_MPU ? "MPU family" : imuType == IMU_LSM ? "LSM6DS3" : "none");
#endif
  float g0x = 0, g0y = 0, g0z = 0, slowMag = 1.0f;
  int nRef = 0;
  int64_t lastVib = 0, lastEnv = 0;
  TickType_t wake = xTaskGetTickCount();

  for (;;) {
    int64_t now = esp_timer_get_time();
    if (state->hasImu) {
      float x, y, z;
      if (readAccelG(x, y, z)) {
        float mag = sqrtf(x * x + y * y + z * z);
        if (nRef < 250) {                          // first ~0.5 s: reference gravity direction
          g0x += x; g0y += y; g0z += z; nRef++;
          slowMag = mag;
        } else {
          slowMag += 0.01f * (mag - slowMag);
          float dev = fabsf(mag - slowMag) * 1000.0f;   // milli-g
          if (dev > VIB_THRESHOLD_MG && now - lastVib > 200000) {
            lastVib = now;
            if (onVib) onVib(now, (uint16_t)fminf(dev, 65535.0f));
          }
          float rx = g0x / nRef, ry = g0y / nRef, rz = g0z / nRef;
          float dot = (x * rx + y * ry + z * rz) / (mag * sqrtf(rx * rx + ry * ry + rz * rz) + 1e-6f);
          float tilt = acosf(fmaxf(-1.0f, fminf(1.0f, dot))) * 57.2958f;
          state->tiltDeg = tilt;
          if (tilt > TILT_MOVED_DEG) state->moved = true;
        }
      }
    }
    if (state->hasEnv && now - lastEnv > 5000000) {
      lastEnv = now;
      float t, h;
      if (readEnv(t, h)) { state->tempC = t; state->rh = h; }
      wake = xTaskGetTickCount();
    }
    vTaskDelayUntil(&wake, pdMS_TO_TICKS(2));    // ~500 Hz IMU sampling
  }
}

static void start(Extras *s, VibCallback cb) {
  state = s;
  onVib = cb;
  if (!ENABLE_ENV && !ENABLE_IMU) return;
  xTaskCreate(task, "extras", 4096, nullptr, 2, nullptr);
}

}  // namespace ext
