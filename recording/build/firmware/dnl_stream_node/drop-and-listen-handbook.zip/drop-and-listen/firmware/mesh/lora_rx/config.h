// config.h for the command-post LoRa receiver (LILYGO LoRa32 #2). Must match the gateway.
#pragma once
#define LORA_SCK   5
#define LORA_MISO  19
#define LORA_MOSI  27
#define LORA_CS    18
#define LORA_RST   23
#define LORA_DIO0  26
#define LORA_DIO1  33
#define LORA_FREQ_MHZ 915.0
#define LORA_BW_KHZ   125.0
#define LORA_SF       7
#define LORA_CR       5
#define LORA_POWER_DBM 17
