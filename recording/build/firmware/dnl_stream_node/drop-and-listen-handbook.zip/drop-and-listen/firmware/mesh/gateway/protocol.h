// protocol.h: shared by node, gateway and lora_rx. Keep all copies IDENTICAL.
// ESP-NOW packets (little-endian, packed). Times are microseconds on the GATEWAY clock;
// nodes convert their own clock using the gateway's beacons.
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define DNL_MAGIC 0xD1
#define DNL_VER   1

enum : uint8_t {
  PKT_BEACON = 1,  // gateway -> all, every second (time sync)
  PKT_SOUND  = 2,  // node -> gateway, one per detected sound
  PKT_STATUS = 3,  // node -> gateway, every 5 s (health, temp/humidity, IMU)
  PKT_VIB    = 4,  // node -> gateway, structure vibration from the IMU
};

#pragma pack(push, 1)
struct PktHeader {
  uint8_t magic;   // DNL_MAGIC
  uint8_t ver;     // DNL_VER
  uint8_t type;    // PKT_*
  uint8_t node;    // node id (0 = gateway)
  uint16_t seq;    // per-sender counter
};

struct PktBeacon {
  PktHeader h;
  uint64_t gw_time_us;  // gateway clock when sent
};

struct PktSound {
  PktHeader h;
  int64_t t_us;          // onset time, gateway clock
  uint16_t peak;         // peak envelope, ADC counts
  uint16_t floor;        // noise floor before the sound, ADC counts
  uint16_t dur_ms;       // how long the sound lasted
  uint16_t rise_ms_x10;  // onset to peak, 0.1 ms units
  uint16_t mod_hz_x10;   // loudness ups and downs per second (syllable rate), 0.1 Hz units
  uint32_t energy;       // summed envelope (relative loudness x duration)
  uint8_t synced;        // 1 if the node clock is synced to the gateway
};

struct PktStatus {
  PktHeader h;
  uint32_t uptime_s;
  uint8_t synced;
  uint8_t has_env;        // temp/humidity sensor present
  int16_t temp_c_x100;
  uint16_t rh_x100;
  uint8_t has_imu;
  uint8_t moved;          // 1 if the node was moved/tilted since boot
  uint16_t tilt_deg_x10;  // current tilt from vertical
  uint16_t noise_floor;   // sound noise floor, ADC counts
};

struct PktVib {
  PktHeader h;
  int64_t t_us;      // gateway clock
  uint16_t peak_mg;  // vibration size, milli-g
  uint8_t synced;
};
#pragma pack(pop)

// Turn one received packet into a JSON line. Returns its length, or 0 if not printable.
// rssi: radio signal strength; gw_now_us: gateway clock when the gateway received it.
inline int dnl_to_json(const uint8_t *d, int len, int rssi, int64_t gw_now_us,
                       const char *via, char *out, size_t cap) {
  if (len < (int)sizeof(PktHeader)) return 0;
  const PktHeader *h = (const PktHeader *)d;
  if (h->magic != DNL_MAGIC || h->ver != DNL_VER) return 0;
  switch (h->type) {
    case PKT_SOUND: {
      if (len < (int)sizeof(PktSound)) return 0;
      const PktSound *p = (const PktSound *)d;
      return snprintf(out, cap,
        "{\"type\":\"sound\",\"node\":%u,\"seq\":%u,\"t_us\":%lld,\"peak\":%u,\"floor\":%u,"
        "\"dur_ms\":%u,\"rise_ms\":%.1f,\"mod_hz\":%.1f,\"energy\":%lu,\"synced\":%u,"
        "\"rssi\":%d,\"gw_us\":%lld,\"via\":\"%s\"}",
        p->h.node, p->h.seq, (long long)p->t_us, p->peak, p->floor, p->dur_ms,
        p->rise_ms_x10 / 10.0, p->mod_hz_x10 / 10.0, (unsigned long)p->energy, p->synced,
        rssi, (long long)gw_now_us, via);
    }
    case PKT_STATUS: {
      if (len < (int)sizeof(PktStatus)) return 0;
      const PktStatus *p = (const PktStatus *)d;
      return snprintf(out, cap,
        "{\"type\":\"status\",\"node\":%u,\"seq\":%u,\"uptime_s\":%lu,\"synced\":%u,"
        "\"has_env\":%u,\"temp_c\":%.2f,\"rh\":%.2f,\"has_imu\":%u,\"moved\":%u,\"tilt_deg\":%.1f,"
        "\"noise_floor\":%u,\"rssi\":%d,\"gw_us\":%lld,\"via\":\"%s\"}",
        p->h.node, p->h.seq, (unsigned long)p->uptime_s, p->synced, p->has_env,
        p->temp_c_x100 / 100.0, p->rh_x100 / 100.0, p->has_imu, p->moved,
        p->tilt_deg_x10 / 10.0, p->noise_floor, rssi, (long long)gw_now_us, via);
    }
    case PKT_VIB: {
      if (len < (int)sizeof(PktVib)) return 0;
      const PktVib *p = (const PktVib *)d;
      return snprintf(out, cap,
        "{\"type\":\"vib\",\"node\":%u,\"seq\":%u,\"t_us\":%lld,\"peak_mg\":%u,\"synced\":%u,"
        "\"rssi\":%d,\"gw_us\":%lld,\"via\":\"%s\"}",
        p->h.node, p->h.seq, (long long)p->t_us, p->peak_mg, p->synced, rssi,
        (long long)gw_now_us, via);
    }
    default:
      return 0;  // beacons are not printed
  }
}
