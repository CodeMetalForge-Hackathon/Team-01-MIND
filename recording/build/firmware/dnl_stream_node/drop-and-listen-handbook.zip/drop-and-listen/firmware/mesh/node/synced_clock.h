// synced_clock.h: converts this node's microsecond clock to the gateway's clock.
// The gateway broadcasts its time every second; every node receives the same beacon at
// practically the same instant, so a line fit over recent beacons gives offset and drift.
#pragma once
#include <Arduino.h>

class SyncedClock {
 public:
  void onBeacon(int64_t localUs, int64_t gwUs) {
    portENTER_CRITICAL(&mux_);
    loc_[head_] = localUs;
    gw_[head_] = gwUs;
    head_ = (head_ + 1) % N;
    if (count_ < N) count_++;
    lastBeaconLocal_ = localUs;
    if (count_ >= 2) fit_();
    portEXIT_CRITICAL(&mux_);
  }

  bool synced() const {
    return count_ >= 2 && (esp_timer_get_time() - lastBeaconLocal_) < 3000000;
  }

  // local microseconds -> gateway microseconds (returns local time if not synced yet)
  int64_t toGateway(int64_t localUs) {
    portENTER_CRITICAL(&mux_);
    int64_t out = count_ >= 2 ? refY_ + (int64_t)llround(a_ + b_ * (double)(localUs - refX_)) : localUs;
    portEXIT_CRITICAL(&mux_);
    return out;
  }

 private:
  static const int N = 8;
  int64_t loc_[N], gw_[N];
  int head_ = 0, count_ = 0;
  int64_t refX_ = 0, refY_ = 0, lastBeaconLocal_ = 0;
  double a_ = 0, b_ = 1;
  portMUX_TYPE mux_ = portMUX_INITIALIZER_UNLOCKED;

  void fit_() {
    int64_t x0 = loc_[0], y0 = gw_[0];
    double mx = 0, my = 0;
    for (int i = 0; i < count_; i++) { mx += (double)(loc_[i] - x0); my += (double)(gw_[i] - y0); }
    mx /= count_; my /= count_;
    double sxy = 0, sxx = 0;
    for (int i = 0; i < count_; i++) {
      double dx = (double)(loc_[i] - x0) - mx, dy = (double)(gw_[i] - y0) - my;
      sxy += dx * dy; sxx += dx * dx;
    }
    b_ = sxx > 0 ? sxy / sxx : 1.0;
    a_ = my - b_ * mx;
    refX_ = x0; refY_ = y0;
  }
};
