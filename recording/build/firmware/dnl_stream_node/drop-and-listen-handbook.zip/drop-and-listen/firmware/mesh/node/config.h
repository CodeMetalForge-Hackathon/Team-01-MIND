// config.h: change these per node.
#pragma once

#define NODE_ID 1                 // 1 for the first node, 2 for the second, ... (unique!)

// Grove sound sensor pin
#if CONFIG_IDF_TARGET_ESP32C5
#define SOUND_PIN 1               // XIAO ESP32-C5: D0 = GPIO1
#elif CONFIG_IDF_TARGET_ESP32S2
#define SOUND_PIN 9               // Adafruit Feather ESP32-S2: pin 9
#else
#define SOUND_PIN 1               // set for your board (must be an ADC1 pin)
#endif

#define SOUND_FS_HZ 10000         // samples per second

// Detector tuning (check with grove_test first)
#define K_TRIGGER 4.0f            // trigger at 4x the noise floor
#define ABS_MIN_COUNTS 15.0f      // ...and at least this many ADC counts

// Optional extras on the I2C pins (XIAO C5: D4 = SDA, D5 = SCL). Auto-detected at boot.
#define ENABLE_ENV 1              // Grove temp & humidity DHT20 / AHT20 (I2C 0x38)
#define ENABLE_IMU 1              // MPU6050-family (0x68/0x69) or LSM6DS3 (0x6A/0x6B)
#define VIB_THRESHOLD_MG 60       // IMU vibration event threshold, milli-g
#define TILT_MOVED_DEG 15.0f      // tilt change that counts as "node moved"

// Optional Grove vibration sensor (digital output) as an extra "felt it" vote.
#define ENABLE_GROVE_VIB 0        // 1 to enable
#define GROVE_VIB_PIN 0           // XIAO ESP32-C5: D1 = GPIO0

#define ESPNOW_CHANNEL 1          // all boards on 2.4 GHz channel 1
#define DEBUG_PRINT 1             // print events as text on USB (harmless)
