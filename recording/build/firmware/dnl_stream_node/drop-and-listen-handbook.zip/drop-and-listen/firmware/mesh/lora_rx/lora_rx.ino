// lora_rx: command-post receiver. Receives packets the gateway forwarded over LoRa and
// prints the same JSON lines as the gateway, so the laptop software doesn't care which
// path the data took. Board: LILYGO LoRa32 ("ESP32 Dev Module"). Library: RadioLib.
#include <Arduino.h>
#include <SPI.h>
#include <RadioLib.h>
#include "config.h"
#include "protocol.h"

SX1276 radio = new Module(LORA_CS, LORA_DIO0, LORA_RST, LORA_DIO1);
static volatile bool packetFlag = false;

#if defined(ESP8266) || defined(ESP32)
ICACHE_RAM_ATTR
#endif
void onPacket(void) { packetFlag = true; }

void setup() {
  Serial.begin(115200);
  delay(500);
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_CS);
  int st = radio.begin(LORA_FREQ_MHZ, LORA_BW_KHZ, LORA_SF, LORA_CR,
                       RADIOLIB_SX127X_SYNC_WORD, LORA_POWER_DBM, 8, 0);
  Serial.printf("{\"type\":\"lora_rx_start\",\"ok\":%s,\"code\":%d}\n",
                st == RADIOLIB_ERR_NONE ? "true" : "false", st);
  if (st != RADIOLIB_ERR_NONE) while (true) delay(1000);
  radio.setPacketReceivedAction(onPacket);
  radio.startReceive();
}

void loop() {
  if (!packetFlag) return;
  packetFlag = false;
  uint8_t buf[96];
  int len = radio.getPacketLength();
  if (len > (int)sizeof(buf)) len = sizeof(buf);
  int st = radio.readData(buf, len);
  if (st == RADIOLIB_ERR_NONE && len > 9) {
    int8_t rssi = (int8_t)buf[0];
    int64_t gwUs;
    memcpy(&gwUs, buf + 1, 8);
    char json[384];
    if (dnl_to_json(buf + 9, len - 9, rssi, gwUs, "lora", json, sizeof(json)) > 0) Serial.println(json);
  }
  radio.startReceive();
}
