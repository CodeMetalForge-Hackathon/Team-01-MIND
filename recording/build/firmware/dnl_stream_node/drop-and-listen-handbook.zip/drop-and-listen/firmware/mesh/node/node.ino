// node: one sensor node. Grove sound sensor (+ optional temp/humidity and IMU).
// Detects sounds on the board, measures their features, stamps them with the gateway's
// clock, and broadcasts tiny ESP-NOW packets. Never sends raw audio.
// Board package: esp32 by Espressif 3.3.5+. Board: XIAO_ESP32C5 (or your board).
// Tools > USB CDC On Boot: Enabled. Set NODE_ID in config.h before flashing each node.
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "soc/soc_caps.h"
#include "esp_adc/adc_continuous.h"
#include "config.h"
#include "protocol.h"
#include "synced_clock.h"
#include "detector.h"
#include "extras.h"

#if CONFIG_IDF_TARGET_ESP32 || CONFIG_IDF_TARGET_ESP32S2
#define ADC_FORMAT ADC_DIGI_OUTPUT_FORMAT_TYPE1
#define ADC_CH(p) ((p)->type1.channel)
#define ADC_DATA(p) ((p)->type1.data)
#else
#define ADC_FORMAT ADC_DIGI_OUTPUT_FORMAT_TYPE2
#define ADC_CH(p) ((p)->type2.channel)
#define ADC_DATA(p) ((p)->type2.data)
#endif

static const uint8_t BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

SyncedClock syncClock;
SoundDetector detector;
Extras extras;

static adc_continuous_handle_t adc = nullptr;
static adc_channel_t soundChannel;
static volatile uint32_t adcOverflows = 0;
static uint8_t adcBuf[256 * SOC_ADC_DIGI_RESULT_BYTES];
static uint16_t seqNo = 0;

struct TxItem { uint8_t len; uint8_t data[63]; };
static QueueHandle_t txQueue;

// sample timing: sample index -> local microseconds (line through all buffers so far)
static int64_t totalSamples = 0, firstIdx = -1, firstT = 0;
static double dtUs = 1e6 / SOUND_FS_HZ;

static void fillHeader(PktHeader &h, uint8_t type) {
  h.magic = DNL_MAGIC; h.ver = DNL_VER; h.type = type; h.node = NODE_ID; h.seq = seqNo++;
}

static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  int64_t now = esp_timer_get_time();            // capture first, before anything else
  if (len < (int)sizeof(PktBeacon)) return;
  const PktBeacon *b = (const PktBeacon *)data;
  if (b->h.magic != DNL_MAGIC || b->h.ver != DNL_VER || b->h.type != PKT_BEACON) return;
  syncClock.onBeacon(now, (int64_t)b->gw_time_us);
}

static bool IRAM_ATTR onAdcOverflow(adc_continuous_handle_t, const adc_continuous_evt_data_t *, void *) {
  adcOverflows++;
  return false;
}

static void queueVib(int64_t localUs, uint16_t peakMg) {   // called from the extras task
  PktVib p;
  fillHeader(p.h, PKT_VIB);
  p.t_us = syncClock.toGateway(localUs);
  p.peak_mg = peakMg;
  p.synced = syncClock.synced();
  TxItem item;
  item.len = sizeof(p);
  memcpy(item.data, &p, sizeof(p));
  xQueueSend(txQueue, &item, 0);
}

#if ENABLE_GROVE_VIB
static volatile int64_t groveVibAt = 0;
static void IRAM_ATTR onGroveVib() { groveVibAt = esp_timer_get_time(); }
#endif

static void setupRadio() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
#ifdef SOC_WIFI_SUPPORT_5G
  esp_wifi_set_band_mode(WIFI_BAND_MODE_2G_ONLY);
#endif
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    while (true) delay(1000);
  }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

static void setupAdc() {
  adc_continuous_handle_cfg_t hcfg = {};
  hcfg.max_store_buf_size = 4096;
  hcfg.conv_frame_size = sizeof(adcBuf);
  ESP_ERROR_CHECK(adc_continuous_new_handle(&hcfg, &adc));

  adc_unit_t unit;
  ESP_ERROR_CHECK(adc_continuous_io_to_channel(SOUND_PIN, &unit, &soundChannel));
  adc_digi_pattern_config_t pattern = {};
  pattern.atten = ADC_ATTEN_DB_12;
  pattern.channel = soundChannel;
  pattern.unit = unit;
  pattern.bit_width = SOC_ADC_DIGI_MAX_BITWIDTH;

  adc_continuous_config_t cfg = {};
  cfg.pattern_num = 1;
  cfg.adc_pattern = &pattern;
  cfg.sample_freq_hz = SOUND_FS_HZ;
  cfg.conv_mode = ADC_CONV_SINGLE_UNIT_1;
  cfg.format = ADC_FORMAT;
  ESP_ERROR_CHECK(adc_continuous_config(adc, &cfg));

  adc_continuous_evt_cbs_t cbs = {};
  cbs.on_pool_ovf = onAdcOverflow;
  adc_continuous_register_event_callbacks(adc, &cbs, nullptr);
  ESP_ERROR_CHECK(adc_continuous_start(adc));
}

static void sendSound(const SoundFeatures &f) {
  PktSound p;
  fillHeader(p.h, PKT_SOUND);
  p.t_us = syncClock.toGateway(f.onsetLocalUs);
  p.peak = (uint16_t)fminf(f.peak, 65535.0f);
  p.floor = (uint16_t)fminf(f.floor, 65535.0f);
  p.dur_ms = (uint16_t)fminf(f.durMs, 65535.0f);
  p.rise_ms_x10 = (uint16_t)fminf(f.riseMs * 10.0f, 65535.0f);
  p.mod_hz_x10 = (uint16_t)fminf(f.modHz * 10.0f, 65535.0f);
  p.energy = (uint32_t)fminf(f.energy, 4.0e9f);
  p.synced = syncClock.synced();
  esp_now_send(BROADCAST, (const uint8_t *)&p, sizeof(p));
#if DEBUG_PRINT
  Serial.printf("[node %d] sound peak %.0f floor %.1f dur %.0f ms rise %.1f ms mod %.1f Hz synced %d\n",
                NODE_ID, f.peak, f.floor, f.durMs, f.riseMs, f.modHz, p.synced);
#endif
}

static void sendStatus() {
  PktStatus p;
  fillHeader(p.h, PKT_STATUS);
  p.uptime_s = (uint32_t)(esp_timer_get_time() / 1000000);
  p.synced = syncClock.synced();
  p.has_env = extras.hasEnv && !isnan(extras.tempC);
  p.temp_c_x100 = p.has_env ? (int16_t)(extras.tempC * 100) : 0;
  p.rh_x100 = p.has_env ? (uint16_t)(extras.rh * 100) : 0;
  p.has_imu = extras.hasImu;
  p.moved = extras.moved;
  p.tilt_deg_x10 = (uint16_t)(extras.tiltDeg * 10);
  p.noise_floor = (uint16_t)detector.noiseFloor();
  esp_now_send(BROADCAST, (const uint8_t *)&p, sizeof(p));
#if DEBUG_PRINT
  Serial.printf("[node %d] status synced %d floor %u adc_overflows %lu temp %.1f rh %.1f tilt %.1f moved %d\n",
                NODE_ID, p.synced, p.noise_floor, (unsigned long)adcOverflows,
                p.has_env ? extras.tempC : NAN, p.has_env ? extras.rh : NAN, extras.tiltDeg, extras.moved);
#endif
}

void setup() {
  Serial.begin(115200);
  delay(500);
  txQueue = xQueueCreate(16, sizeof(TxItem));
  setupRadio();
  detector.begin(SOUND_FS_HZ);
  setupAdc();
  ext::start(&extras, queueVib);
#if ENABLE_GROVE_VIB
  pinMode(GROVE_VIB_PIN, INPUT);
  attachInterrupt(GROVE_VIB_PIN, onGroveVib, RISING);
#endif
#if DEBUG_PRINT
  Serial.printf("[node %d] up, MAC %s, sound pin %d\n", NODE_ID, WiFi.macAddress().c_str(), SOUND_PIN);
#endif
}

void loop() {
  uint32_t n = 0;
  if (adc_continuous_read(adc, adcBuf, sizeof(adcBuf), &n, 20) == ESP_OK) {
    int64_t tEnd = esp_timer_get_time();
    int results = n / SOC_ADC_DIGI_RESULT_BYTES;
    if (firstIdx < 0) { firstIdx = totalSamples; firstT = tEnd - (int64_t)(results * dtUs); }
    for (int i = 0; i < results; i++) {
      adc_digi_output_data_t *p = (adc_digi_output_data_t *)&adcBuf[i * SOC_ADC_DIGI_RESULT_BYTES];
      if (ADC_CH(p) != soundChannel) continue;
      int64_t t = firstT + (int64_t)((totalSamples - firstIdx) * dtUs);
      totalSamples++;
      SoundFeatures f;
      if (detector.process(ADC_DATA(p), t, &f)) sendSound(f);
    }
    if (totalSamples - firstIdx > SOUND_FS_HZ) dtUs = (double)(tEnd - firstT) / (double)(totalSamples - firstIdx);
  }

#if ENABLE_GROVE_VIB
  static int64_t lastGroveVib = 0;
  int64_t gv = groveVibAt;
  if (gv != 0 && gv - lastGroveVib > 200000) { lastGroveVib = gv; queueVib(gv, 0); }
#endif

  TxItem item;
  while (xQueueReceive(txQueue, &item, 0) == pdTRUE) esp_now_send(BROADCAST, item.data, item.len);

  static uint32_t lastStatus = 0;
  if (millis() - lastStatus > 5000) { lastStatus = millis(); sendStatus(); }
}
